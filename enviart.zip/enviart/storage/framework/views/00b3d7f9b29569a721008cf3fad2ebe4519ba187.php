
<?php $__env->startSection('mainarea'); ?>
<?php $data=DB::table('users')->where('id',Auth::user()->id)->first(); ?>
<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/jquery-3.3.1/jquery-3.3.1.js')); ?>"></script>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
	  <div class="container-full">
		<!-- Content Header (Page header) -->	  
		<div class="content-header">
			<div class="d-flex align-items-center">
				<div class="mr-auto">
					<h3 class="page-title">Setting</h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item active" aria-current="page">Control</li>
							</ol>
						</nav>
					</div>
				</div>
				<div class="right-title w-170">
				</div>
			</div>
		</div>

		<!-- Main content -->
		<section class="content">

		  <div class="row">
			<div class="col-lg-6 connectedSortable ui-sortable">
			  <!-- Default box -->
			  <div class="box">
				<div class="box-header with-border ui-sortable-handle" style="cursor: move;">
				  <h4 class="box-title">Profile Management</h4>

				  <ul class="box-controls pull-right">
					<li><a class="box-btn-close" href="#"></a></li>
					<li><a class="box-btn-slide" href="#"></a></li>	
				  </ul>
				</div>
				<div class="box-body p-0">
				    <?php if(session()->has('status')): ?>
            		<div class="alert alert-info">
            				<?php echo e(session()->get('status')); ?>

            			</div>
            		<?php endif; ?>
				  <ul class="todo-list ui-sortable">
					<li class="p-15">
					  <div class="box p-15 mb-0 d-block bb-2 border-secondary">
						 <!-- drag handle -->
						  <form novalidate action="<?php echo e(url('admin/updateprofile')); ?>" method="POST" enctype="multipart/form-data">
        				        <?php echo csrf_field(); ?>
        					<div class="form-group row">
        						<label class="col-form-label col-md-2">Name</label>
        						<div class="col-md-10">
        						    <div class="controls">
        							<input value="<?php echo e($data->name); ?>" class="form-control" type="text" name="name" required data-validation-required-message="This field is required">
        						    </div>
        						</div>
        					</div>
        
        					<div class="form-group row">
        						<label class="col-form-label col-md-2">Email</label>
        						<div class="col-md-10">
        							<div class="controls">
        								<input value="<?php echo e($data->email); ?>" type="email" name="email" class="form-control" required data-validation-required-message="This field is required"> 
        							</div>
        						</div>
        					</div>	
        					<div class="form-group row">
        						<label class="col-form-label col-md-2">Profile image</label>
        						<div class="col-md-10">
        							<div class="controls">
        								<input type="file" name="image" class="form-control" required data-validation-required-message="This field is required"> 
        							</div>
        						</div>
        					</div>	
        					<div class="text-xs-left">
        						<button type="submit" class="btn btn-info">Update</button>
        					</div>
        				</form>
					  </div>
					</li>
				  </ul>
				</div>
				<!-- /.box-body -->
			  </div>
			  <!-- /.box -->
			</div>
			<div class="col-lg-6 connectedSortable ui-sortable">
			  <!-- Default box -->
			  <div class="box">
				<div class="box-header with-border ui-sortable-handle" style="cursor: move;">
				  <h4 class="box-title">Change Password</h4>

				  <ul class="box-controls pull-right">
					<li><a class="box-btn-close" href="#"></a></li>
					<li><a class="box-btn-slide" href="#"></a></li>	
				  </ul>
				</div>
				<div class="box-body p-0">
				    <?php if(session()->has('change_password_status')): ?>
            		<div class="alert alert-info">
            				<?php echo e(session()->get('change_password_status')); ?>

            			</div>
            		<?php endif; ?>
				  <ul class="todo-list ui-sortable">
					<li class="p-15">
					  <div class="box p-15 mb-0 d-block bb-2 border-danger">
						 <form novalidate action="<?php echo e(url('admin/changepassword')); ?>" method="POST">
        				        <?php echo csrf_field(); ?>
        					<div class="form-group row">
        						<label class="col-form-label col-md-2">Old password</label>
        						<div class="col-md-10">
        						    <div class="controls">
        							<input class="form-control" type="password" name="old_password" required data-validation-required-message="This field is required">
        						    </div>
        						</div>
        					</div>
        
        					<div class="form-group row">
        						<label class="col-form-label col-md-2">New password</label>
        						<div class="col-md-10">
        							<div class="controls">
        								<input type="password" name="new_password" class="form-control" required data-validation-required-message="This field is required"> 
        							</div>
        						</div>
        					</div>	
        					<div class="form-group row">
        						<label class="col-form-label col-md-2">Confirm password</label>
        						<div class="col-md-10">
        							<div class="controls">
        								<input type="password" name="confirm_password" class="form-control" required data-validation-required-message="This field is required"> 
        							</div>
        						</div>
        					</div>	
        					<div class="text-xs-left">
        						<button type="submit" class="btn btn-info">Update</button>
        					</div>
        				</form>
					  </div>
					</li>
				  </ul>
				</div>
				<!-- /.box-body -->
			  </div>
			  <!-- /.box -->
			</div>
		  </div>
		</section>
		<!-- /.content -->
	  </div>
  </div>
  <!-- /.content-wrapper -->
    <script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/jquery-3.3.1/jquery-3.3.1.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/pages/validation.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/pages/form-validation.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/scsyin/public_html/spiritualIndia/resources/views/admin/profile.blade.php ENDPATH**/ ?>