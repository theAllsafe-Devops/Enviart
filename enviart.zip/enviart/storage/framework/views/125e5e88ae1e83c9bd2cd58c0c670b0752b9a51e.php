<footer class="main-footer">
	  <!--Developed by By <a href="https://theallsafe.com/">Theallsafe</a>-->
  </footer><?php /**PATH /home3/scsyin/public_html/callrecording/resources/views/admin/include/footer.blade.php ENDPATH**/ ?>