<?php $data=DB::table('users')->where('id','1')->first();  
$qr=QrCode::generate("https://gulfbills.com".$_SERVER['REQUEST_URI']); 
?>
<!DOCTYPE html>
<html lang="en">

<head>
<style>
    th{
        padding:4px !important;
    }
</style>
<style>
table, th, td {
  border: 1px solid black !important;
  padding:0px !important;

}
</style>
  <?php echo $__env->make('admin.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="g-sidenav-show bg-gray-100">
  <main class="main-content max-height-vh-100 h-100">
    <div class="container-fluid my-3 py-3">
      <div class="row">
        <div class="col-md-8 col-sm-12 mx-auto">
          <form class="" method="post">
            <div class="card" id="printarea">
              <div class="card-header">
                <div class="row justify-content-between">
                  <div class="col-5 col-md-4 text-md-end text-start" style="text-align: left !important;">
                    <h6 class="d-block mt-2 mb-0"><?php echo e($data->shop_name); ?> </h6>
                    <span class="text-secondary"><?php echo e($data->address); ?>

                    </span><br>
                    <span class="text-dark text-secondary">Contact: </span><span><?php echo e($data->telephone_no); ?></span><br>
                    <span class="text-dark text-secondary">Email:  </span><span><?php echo e($data->email_id_print); ?></span><br>
                    <span class="text-dark text-secondary">VAT No : </span><span><?php echo e($data->vat_license_no); ?></span>
                  </div>
                  <div class="col-2 col-md-2 text-md-end text-start">
                    <img class="mb-2 w-100 p-2" src="<?php echo e(URL::asset('public/assets/img/')); ?>/<?php echo e($data->logo); ?>" alt="Logo">
                  </div>
                  <div class="col-5 col-md-5 text-md-end text-end">
                    <h6 class="d-block mt-2 mb-0"><?php echo e($data->shop_name_arabic); ?></h6>
                    <span class="text-secondary"><?php echo e($data->address_arabic); ?>

                    </span><br>
                    <span class="text-dark text-secondary">اتصل: </span><span><?php echo e($data->telephone_no_arabic); ?></span><br>
                    <span class="text-dark text-secondary">بريد الالكتروني:  </span><span><?php echo e($data->email_id_print_arabic); ?></span><br>
                    <span class="text-dark text-secondary">ضريبة القيمة المضافة لا : </span><span><?php echo e($data->vat_license_no_arabic); ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12">
                    <div class="table-responsive">
                      <table class="table text-right">
                        <thead>
                          <tr>
                            <th style="font-weight:bold; color:black;padding: 5px !important;" scope="col" class="pe-2 text-center ps-2" colspan="3">INVOICE فاتورة</th>
                          </tr>
                          <tr>
                            <th scope="col" class="pe-2 text-start ps-2" style="font-size: 0.875rem !important; font-weight: unset;">Invoice Number: <?php echo e($row->id); ?></th>
                            <th scope="col" class="pe-2 text-end ps-2">رقم الفاتورة </th>
                            <th scope="col" class="pe-2 ps-2" rowspan="4" width="13%"><div><?php echo e($qr); ?></div></th>
                          </tr>
                          <tr>
                            <th scope="col" class="pe-2 text-start ps-2" style="font-size: 0.875rem !important; font-weight: unset;">Invoice Issue Date: <?php $originalDate = $row->created_at; echo date("d-m-Y", strtotime($originalDate)); ?></th>
                            <th scope="col" class="pe-2 text-end ps-2">تاريخ اصدار الفاتورة</th>
                          </tr>
                          <tr>
                            <th scope="col" class="pe-2 text-start ps-2" style="font-size: 0.875rem !important; font-weight: unset;">Payment Mode: <?php echo e($row->payment_type); ?></th>
                            <th scope="col" class="pe-2 text-end ps-2">   نوع الدفع      
                            <?php if($row->payment_type=="Credit"): ?> 
                            اجل
                            
                            <?php endif; ?>
                            
                            <?php if($row->payment_type=="Online"): ?> 
                            اون لاين
                            
                            
                            <?php endif; ?>
                            
                            
                            <?php if($row->payment_type=="Cash"): ?> 
                            نقد
                            
                            
                            <?php endif; ?>
                            
                            
                            
                            </th>
                          </tr>
                          <tr>
                            <th scope="col" class="pe-2 text-start ps-2" colspan="3" style="font-size: 0.875rem !important; font-weight: unset;">Customer : <?php echo e($row->customer_name); ?></th>
                          </tr>
                          <tr>
                            <th scope="col" class="pe-2 text-start ps-2" colspan="3" style="font-size: 0.875rem !important; font-weight: unset;">Customer VAT No : <?php echo e($row->customer_vat_no); ?></th>
                          </tr>
                        </thead>
                      </table>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12">
                    <div class="table-responsive">
                      <table class="table text-right" border="2">
                        <thead class="bg-default">
                          <tr style="background: #E2E2E2;">
                            <th scope="col" class="pe-2 text-start ps-2" style="width: 55% !important;">Description<br> البيا نا ت  </th>
                            <th scope="col" class="pe-2 text-center" style="width: 15% !important;">Unit Price (SAR)<br> السعر الوحدة</th>
                            <th scope="col" class="pe-2 text-center" style="width: 15% !important;">Quantity<br>  الكمية</th>
                            <th scope="col" class="pe-2 text-end" style="width: 15% !important;">Sub total<br> المجموعة</th>
                          </tr>
                        </thead>
                        <tbody><?php $item=DB::table('tbl_invoiceOrderItemTable')->where('tbl_invoiceOrderItemTable.order_id',$row->id)->get(); ?>
                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td class="text-left"  style="white-space: break-spaces;width: 100px !important;  padding-left: 7px !important;"><?php echo e($value->item_id); ?></td>
                            <td class="ps-4 text-center"><?php echo e($value->price); ?></td>
                            <td class="text-center"><?php echo e($value->order_item_quantity); ?></td>
                            <td class="ps-4 text-end" style=" padding-right: 7px !important;"><?php echo e($value->order_item_final_amount); ?></td>
                          </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                          <tr>
                            <th class="text-end h6" colspan="3" style="padding-right: 8px !important;font-size: 0.875rem !important; font-weight: unset;">Sub Total الاجمالي ا</th>
                            <th class="text-end h6" style="padding-right: 8px !important;"><?php echo e($row->order_total_before_tax); ?></th>
                          </tr>
                          <tr>
                            <th class="text-end h6" colspan="3" style="padding-right: 8px !important;font-size: 0.875rem !important; font-weight: unset;font-size: 0.875rem !important; font-weight: unset;">Discount  الخصم </th>
                            <th class="text-end h6" style="padding-right: 8px !important;"><?php echo e($row->order_amount_paid); ?></th>
                          </tr>
                          <tr>
                            <th class="text-end h6" colspan="3" style="padding-right: 8px !important;font-size: 0.875rem !important; font-weight: unset;">VAT-<?php echo e($row->order_total_tax); ?>% ض</th>
                            <th class="text-end h6 ps-4" style="padding-right: 8px !important;"><?php echo e($row->order_tax_per); ?></th>
                          </tr>
                          <tr>
                            <th class="text-end h6" colspan="3" style="padding-right: 8px !important;">Grand Total الاجمالي المبلغ </th>
                            <th class="text-end h6 ps-4" style="padding-right: 8px !important;">SAR <?php echo e($row->order_total_amount_due); ?></th>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-5 text-left">
                    <h5>Remarks</h5>
                    <p class="text-secondary text-sm"><?php echo e($data->remark); ?></p>
                    <p class="text-secondary text-sm"> </p>
                    <h6 class="text-secondary mb-0">
                      Salesman Signature
                      <span class="text-dark">توقيع البايع</span>
                    </h6>
                  </div>
                  <div class="col-4 text-left">
                  </div>
                  <div class="col-3  text-md-end text-end">
                    <h5>ملاحظات</h5>
                    <p class="text-secondary text-sm"><?php echo e($data->remark_arabic); ?></p>
                    <h6 class="text-secondary mb-0">
                      Received BY  
                      <span class="text-dark">توقيع المستلم</span>
                    </h6>
                  </div>
                </div>
             </div>
            </div>
          </form>
        </div>
      </div>
      <button id="printpagebutton" class="btn bg-gradient-info mt-lg-7 mb-0"  onclick="printpage()" type="button" name="button">Print</button>
        <a href="<?php echo e(url('admin/dashboard')); ?>" id="invoice" class="btn bg-gradient-info mt-lg-7 mb-0"  name="button">Back To Home</a>
    </div>
  </main>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
 function printpage() {
     var printContents = document.getElementById("printarea").innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    //  $("#printarea").print();
        //Get the print button and put it into a variable
        // var printButton = document.getElementById("printpagebutton");
        // var invoice = document.getElementById("invoice");
        //Set the print button visibility to 'hidden' 
        // printButton.style.visibility = 'hidden';
        // invoice.style.visibility = 'hidden';
        //Print the page content
        // window.print()
        // printButton.style.visibility = 'visible';
        // invoice.style.visibility = 'visible';
    }
    // var win = navigator.platform.indexOf('Win') > -1;
    // if (win && document.querySelector('#sidenav-scrollbar')) {
    //   var options = {
    //     damping: '0.5'
    //   }
    //   Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    // }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
</body>

</html><?php /**PATH /home/blueczur/gulfbills.com/mct/resources/views/admin/bill/invoice.blade.php ENDPATH**/ ?>