
<?php $__env->startSection('mainarea'); ?>
<style>
    .select2 {
        width: 305px !important;
    }
</style>
<script src="<?php echo e(URL::asset('public/assets/js/plugins/datatables.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('.js-example-basic-single').select2({
  tags: true
});

});
</script>
	<div class="container-fluid py-4">
	    <?php if(session()->has('status')): ?>
        <div class="alert alert-success" role="alert">
          <strong>Success!</strong> <?php echo e(session()->get('status')); ?>

      `</div>
		<?php endif; ?>
		<?php if($errors->any()): ?>
		  <div class="alert alert-danger" role="alert" style="color:white;">
              <strong>Warning!</strong>  <?php echo e(implode('', $errors->all(':message'))); ?>

          </div>
		<?php endif; ?>
        <form action="<?php echo e(url('admin/bill/store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
          <div class="row">
                <div class="col-lg-8 col-12 mx-auto" style="margin-top: 21px;">
                  <div class="card">
                    <div class="card-header pb-0">
                      <div class="d-lg-flex">
                        <div <?php if(session('type')==0): ?>   class="ms-auto my-auto mt-lg-0 mt-4"   <?php endif; ?>>
                          <h5 class="mb-0">  <?php if(session('type')==0): ?> فاتورة    <?php else: ?>  Invoice <?php endif; ?></h5>
                        </div>
                        <div class="ms-auto my-auto mt-lg-0 mt-4">
                          <div class="ms-auto my-auto">
                            <button class="btn btn-info" id="addRows" type="button">+ <?php if(session('type')==0): ?> أضف المزيد   <?php else: ?> Add More  <?php endif; ?> </button>
                            <button class="btn btn-info delete" id="removeRows" type="button">- <?php if(session('type')==0): ?> حذف   <?php else: ?> Delete  <?php endif; ?> </button>
        				  </div>
                        </div>
                      </div>
                    </div>
                    <div class="card-body px-0 pb-0">
                      <div class="table-responsive">
                        <table class="table table-flush" id="invoiceItem">
                          <thead class="thead-light">
                            <tr>
        						<th><input id="checkAll" class="formcontrol" type="checkbox"></th>
        						<th><?php if(session('type')==0): ?> اسم المنتج <?php else: ?> Product Name  <?php endif; ?></th>
        						<th><?php if(session('type')==0): ?> كمية <?php else: ?> Quantity <?php endif; ?></th>
        						<th><?php if(session('type')==0): ?> السعر <?php else: ?> Price <?php endif; ?></th>								
        						<th><?php if(session('type')==0): ?> المجموع <?php else: ?> Total <?php endif; ?></th>
        					</tr>
                          </thead>
                          <tbody>
                            <tr>
        						<td><input class="itemRow" type="checkbox" style="margin-left: 15px;"></td><td>
        						    <select name="productName[]" id="productName_1" class="js-example-basic-single select-product form-control" autocomplete="off">
        						        <option value=""><?php if(session('type')==0): ?> حدد المنتج <?php else: ?> Select Product  <?php endif; ?> </option>  
        						        <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        						        <option value="<?php echo e($value->product_name); ?>"><?php echo e($value->product_name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        						        <!--<option value="" ><?php if(session('type')==0): ?> حدد المنتج <?php else: ?> Select Product  <?php endif; ?> </opti-->
        						    </select>
        						</td>			
        						<td><input type="number" name="quantity[]" id="quantity_1" class="form-control quantity" autocomplete="off"></td>
        						<td><input type="number" name="price[]" id="price_1" class="form-control price" autocomplete="off"></td>
        						<td><input type="number" name="total[]" id="total_1" class="form-control total" autocomplete="off"></td>
        					</tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-12 mx-auto" style="margin-top: 21px;">
                  <div class="card">
                    <div class="card-body px-0 pb-0">
                      <div class="table-responsive">
                        <table class="table table-flush">
                            <tr>
        						<td><?php if(session('type')==0): ?> اسم الزبون            <?php else: ?>            Customer Name  <?php endif; ?></td>			
        						<td><input value="" type="text" class="form-control" name="customer_name" placeholder="<?php if(session('type')==0): ?> اسم الزبون <?php else: ?> Customer Name  <?php endif; ?>"></td>
        					</tr>
        					<tr>
        						<td><?php if(session('type')==0): ?> ضريبة القيمة المضافة للعميل           <?php else: ?>          Customer VAT No        <?php endif; ?></td>			
        						<td><input value="" type="text" class="form-control" name="customer_vat_no" placeholder="<?php if(session('type')==0): ?> ضريبة القيمة المضافة المخصصة           <?php else: ?> Customer VAT No        <?php endif; ?>"></td>
        					</tr>
                            <tr>
        						<td><?php if(session('type')==0): ?> المجموع الفرعي  <?php else: ?> Subtotal    <?php endif; ?></td>			
        						<td><input value="" type="text" class="form-control" name="subTotal" id="subTotal" placeholder="<?php if(session('type')==0): ?> المجموع الفرعي  <?php else: ?> Subtotal    <?php endif; ?>"></td>
        					</tr>
        					<tr>
        						<td><?php if(session('type')==0): ?>تشمل ضريبة القيمة المضافة         <?php else: ?> Include VAT  <?php endif; ?></td>			
        						<td><input class="taxRate" value="<?php echo e($tax->precentage); ?>" type="checkbox" name="taxRate" id="taxRate"></td>
        					</tr>
        					<tr>
        						<td><?php if(session('type')==0): ?>قيمة الضريبة           <?php else: ?> VAT Amount  <?php endif; ?></td>			
        						<td><input value="" type="text" class="form-control" name="taxAmount" id="taxAmount" placeholder="<?php if(session('type')==0): ?> قيمة الضريبة <?php else: ?> Tax Amount  <?php endif; ?>"></td>
        					</tr>
        					<tr>
        						<td><?php if(session('type')==0): ?> المجموع <?php else: ?> Total  <?php endif; ?></td>			
        						<td><input value="" type="text" class="form-control" name="totalAftertax" id="totalAftertax" placeholder="<?php if(session('type')==0): ?> المجموع <?php else: ?> Total  <?php endif; ?>"></td>
        					</tr>
        					<tr>
        						<td><?php if(session('type')==0): ?> خصم <?php else: ?> Discount  <?php endif; ?>  </td>			
        						<td><input value="" type="text" class="form-control" name="amountPaid" id="amountPaid" placeholder="<?php if(session('type')==0): ?> خصم <?php else: ?> Discount  <?php endif; ?> "></td>
        					</tr>
        					<tr>
        						<td><?php if(session('type')==0): ?> المبلغ المستحق <?php else: ?> Amount Due  <?php endif; ?></td>			
        						<td><input value="" type="text" class="form-control" name="amountDue" id="amountDue" placeholder="<?php if(session('type')==0): ?> المبلغ المستحق <?php else: ?> Amount Due  <?php endif; ?>"></td>
        					</tr>
        					<tr>
        						<td><?php if(session('type')==0): ?> نوع الدفع <?php else: ?> Payment type  <?php endif; ?></td>			
        						<td><select class="form-control" name="payment_type">
        						        <option value=""><?php if(session('type')==0): ?>  يختار      <?php else: ?> Select  <?php endif; ?></option>
        						        <option> <?php if(session('type')==0): ?> نقد <?php else: ?>    Cash      <?php endif; ?></option>
        						        <option><?php if(session('type')==0): ?> اون لاين <?php else: ?> Online <?php endif; ?></option>
        						        <option><?php if(session('type')==0): ?>اجل <?php else: ?> Credit <?php endif; ?></option>
        						    </select>
        						</td>
        					</tr>
        					<tr>
        						<td></td>			
        						<td><button type="submit" name="button" class="btn bg-gradient-info m-0 ms-2"><?php if(session('type')==0): ?>مطبعة <?php else: ?> Print <?php endif; ?></button></td>
        					</tr>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
          </div>
        </form>
    </div>
<script>
    
 $(document).ready(function(){
     
	$(document).on('change', '.select-product', function() {   
	    var product_id = $(this).val();
	    var id = $(this).attr('id');
		id = id.replace("productName_",'');
	    $.ajax({
        type: "get",
        dataType: "json",
        url: "<?php echo e(URL::asset('admin/getproduct')); ?>",
        data: { _token:'<?php echo e(csrf_token()); ?>','product_id':product_id},

        success: function (response) {
           $('#price_'+id).val(response.price);
           
        }
        });
	});	
	$(document).on('click', '#checkAll', function() {          	
		$(".itemRow").prop("checked", this.checked);
	});	
	$(document).on('click', '.itemRow', function() {  	
		if ($('.itemRow:checked').length == $('.itemRow').length) {
			$('#checkAll').prop('checked', true);
		} else {
			$('#checkAll').prop('checked', false);
		}
	});  
	var count = $(".itemRow").length;
	$(document).on('click', '#addRows', function() { 
		count++;
		var htmlRows = '';
		htmlRows += '<tr>';
		htmlRows += '<td><input class="itemRow" type="checkbox" style="margin-left: 15px;"></td>'; 
		htmlRows += '<td><select name="productName[]" id="productName_'+count+'" class="js-example-basic select-product form-control" autocomplete="off"><option value=""><?php if(session('type')==0): ?> حدد المنتج <?php else: ?> Select Product  <?php endif; ?></option> <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>					        <option value="<?php echo e($value->product_name); ?>"><?php echo e($value->product_name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       </select></td>';	
		htmlRows += '<td><input type="number" name="quantity[]" id="quantity_'+count+'" class="form-control quantity" autocomplete="off"></td>';   		
		htmlRows += '<td><input type="number" name="price[]" id="price_'+count+'" class="form-control price" autocomplete="off"></td>';		 
		htmlRows += '<td><input type="number" name="total[]" id="total_'+count+'" class="form-control total" autocomplete="off"></td>';          
		htmlRows += '</tr>';
		$('#invoiceItem').append(htmlRows);
		 $('.js-example-basic').select2({
  tags: true
});
	}); 
	$(document).on('click', '#removeRows', function(){
		$(".itemRow:checked").each(function() {
			$(this).closest('tr').remove();
		});
		$('#checkAll').prop('checked', false);
		calculateTotal();
	});		
	$(document).on('blur', "[id^=quantity_]", function(){
		calculateTotal();
	});	
	$(document).on('blur', "[id^=price_]", function(){
		calculateTotal();
	});	
	$(document).on('blur', "#taxRate", function(){		
		calculateTotal();
	});	
	$(document).on('blur', "#amountPaid", function(){
		var amountPaid = $(this).val();
		var totalAftertax = $('#totalAftertax').val();	
		if(amountPaid && totalAftertax) {
			totalAftertax = totalAftertax-amountPaid;			
			$('#amountDue').val(totalAftertax);
		} else {
			$('#amountDue').val(totalAftertax);
		}	
	});	
	$(document).on('click', '.deleteInvoice', function(){
		var id = $(this).attr("id");
		if(confirm("Are you sure you want to remove this?")){
			$.ajax({
				url:"action.php",
				method:"POST",
				dataType: "json",
				data:{id:id, action:'delete_invoice'},				
				success:function(response) {
					if(response.status == 1) {
						$('#'+id).closest("tr").remove();
					}
				}
			});
		} else {
			return false;
		}
	});
});	
function calculateTotal(){
	var totalAmount = 0; 
	$("[id^='price_']").each(function() {
		var id = $(this).attr('id');
		id = id.replace("price_",'');
		var price = $('#price_'+id).val();
		var quantity  = $('#quantity_'+id).val();
		if(!quantity) {
			quantity = 1;
		}
		var total = price*quantity;
		$('#total_'+id).val(parseFloat(total));
		totalAmount += total;			
	});
	$('#subTotal').val(parseFloat(totalAmount));	
    // 	var taxRate = $("input[type='radio'][name='taxRate']:checked");
    // 	alert(taxRate);
    var taxRate=0;
	if($("input[type='checkbox'].taxRate").is(':checked')) {
        var taxRate = $("input[type='checkbox'].taxRate:checked").val();
    }
    // 	var taxRate = $("#taxRate").val();
	var subTotal = $('#subTotal').val();	
	if(subTotal) {
		var taxAmount = subTotal*taxRate/100;
		$('#taxAmount').val(taxAmount);
		subTotal = parseFloat(subTotal)+parseFloat(taxAmount);
		$('#totalAftertax').val(subTotal);		
		var amountPaid = $('#amountPaid').val();
		var totalAftertax = $('#totalAftertax').val();	
		if(amountPaid && totalAftertax) {
			totalAftertax = totalAftertax-amountPaid;			
			$('#amountDue').val(totalAftertax);
		} else {		
			$('#amountDue').val(subTotal);
		}
	}
}

 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blueczur/gulfbills.com/mct/resources/views/admin/bill/create.blade.php ENDPATH**/ ?>