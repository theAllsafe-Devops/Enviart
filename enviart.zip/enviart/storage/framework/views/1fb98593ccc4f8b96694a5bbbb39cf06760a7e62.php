<html>
    <p>Welcome , <br>
    <p>Mobile Number : <b><?php echo e($mobile_no); ?></b></p>
    <p>Password : <b><?php echo e($password); ?></b></p>
    <p>Email : <b><?php echo e($email); ?></b></p>
</html><?php /**PATH /home3/scsyin/public_html/callrecording/resources/views/admin/mail.blade.php ENDPATH**/ ?>