
<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>
			
                <!--aside closed-->
				<div class="app-content main-content">
					<div class="side-app">
						<!--app header-->
						<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<!--/app header-->
												<!--Page header-->
						<div class="page-header">
							<div class="page-leftheader">
								<h4 class="page-title">Crypto Dashboard</h4>
							</div>
							<div class="page-rightheader ml-auto d-lg-flex d-none">
								<div class="ml-5 mb-0">
									<a class="btn btn-white date-range-btn" href="#" id="daterange-btn">
										<svg class="header-icon2 mr-3" x="1008" y="1248" viewBox="0 0 24 24"  height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false">
											<path d="M5 8h14V6H5z" opacity=".3"/><path d="M7 11h2v2H7zm12-7h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10zm0-12H5V6h14v2zm-4 3h2v2h-2zm-4 0h2v2h-2z"/>
										</svg> <span>Select Date
										<i class="fa fa-caret-down"></i></span>
									</a>
								</div>
							</div>
						</div>
						<!--End Page header-->
												<!--Row-->
						<div class="row">
							<div class="col-xl-12 col-md-12 col-lg-12">
								<div class="">
									<div class="js-conveyor-example">
										<ul class="news-crypto">
											<li>
											  <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/AquariusCoin.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$0.0215</span> <span class="text-muted fs-10">USD</span><span class="text-danger ml-4"><i class="ion-arrow-down-c mr-1"></i>-0.78%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/Augur.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$425.25 </span> <span class="text-muted fs-10">USD</span><span class="text-success ml-4"><i class="ion-arrow-up-c mr-1"></i>+12.85% </span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/Bitcoin.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$2.786</span>  <span class="text-muted fs-10">USD</span><span class="text-success ml-4"><i class="ion-arrow-up-c mr-1"></i>-02.25%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/BitConnect.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$15.425 </span> <span class="text-muted fs-10">USD</span><span class="text-danger ml-4"><i class="ion-arrow-down-c mr-1"></i>-0.78%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/BitShares.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$5.125 </span> <span class="text-muted fs-10">USD</span><span class="text-success ml-4"><i class="ion-arrow-up-c mr-1"></i>-11.85% </span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/Bytecoin.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$135.425 </span> <span class="text-muted fs-10">USD</span><span class="text-danger ml-4"><i class="ion-arrow-down-c mr-1"></i>-0.78%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/Dash.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$34.625 </span> <span class="text-muted fs-10">USD</span><span class="text-success ml-4"><i class="ion-arrow-up-c mr-1"></i>-0.32%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/Decred.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$67.325 </span> <span class="text-muted fs-10">USD</span><span class="text-danger ml-4"><i class="ion-arrow-down-c mr-1"></i>-0.78%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/EOS.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$7.525 </span> <span class="text-muted fs-10">USD</span><span class="text-success ml-4"><i class="ion-arrow-up-c mr-1"></i>-1.42%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/Ethereum.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$4.325 </span> <span class="text-muted fs-10">USD</span><span class="text-danger ml-4"><i class="ion-arrow-down-c mr-1"></i>-0.78%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/Golem.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$5.525 </span> <span class="text-muted fs-10">USD</span><span class="text-success ml-4"><i class="ion-arrow-up-c mr-1"></i>-1.32%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/Iconomi.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$6.025 </span> <span class="text-muted fs-10">USD</span><span class="text-danger ml-4"><i class="ion-arrow-down-c mr-1"></i>-0.78%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/IOTA.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">0.0215 </span> <span class="text-muted fs-10">USD</span><span class="text-success ml-4"><i class="ion-arrow-up-c mr-1"></i>-0.45%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/LanaCoin.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$0.125 </span> <span class="text-muted fs-10">USD</span><span class="text-danger ml-4"><i class="ion-arrow-down-c mr-1"></i>-0.78%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/Litecoin.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$1.125 </span> <span class="text-muted fs-10">USD</span><span class="text-success ml-4"><i class="ion-arrow-up-c mr-1"></i>-0.65%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/Monero.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">$0.725 </span> <span class="text-muted fs-10">USD</span><span class="text-danger ml-4"><i class="ion-arrow-down-c mr-1"></i>-0.36%</span></span>
											</li>
											<li>
											   <span><img src="<?php echo e(URL::asset('admin_assets/images/crypto-currencies/round-outline/NEM.svg')); ?>" class="w-5 h-5 mr-2" alt=""><span class="font-weight-bold">0.0215 </span> <span class="text-muted fs-10">USD</span><span class="text-success ml-4"><i class="ion-arrow-up-c mr-1"></i>-0.78%</span></span>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!--End Row-->


					</div>
				</div><!-- end app-content-->

<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\laravel\theallsafe\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>