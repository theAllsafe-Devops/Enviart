<!DOCTYPE html>
<html lang="en">
  <?php echo $__env->make('partner.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="skin-info sidebar-mini light-sidebar">
<div class="wrapper">

  <?php echo $__env->make('partner.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
  <?php echo $__env->make('partner.include.siderbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <?php echo $__env->yieldContent('mainarea'); ?>
  <!-- /.content-wrapper -->
	
  <?php echo $__env->make('partner.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Add the sidebar's background. This div must be placed immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
  
</div>
<!-- ./wrapper -->
	<?php echo $__env->make('partner.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
</body>
</html>
<?php /**PATH /home3/scsyin/public_html/schoolbuddy/schoolbuddy/resources/views/partner/include/layout.blade.php ENDPATH**/ ?>