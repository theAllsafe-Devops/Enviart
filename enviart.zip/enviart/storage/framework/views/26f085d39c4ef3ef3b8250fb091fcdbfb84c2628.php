<html>
    <p>Welcome , OTP : <?php echo e($otp); ?></b></p>
</html><?php /**PATH /home3/scsyin/public_html/gym/resources/views/admin/mail.blade.php ENDPATH**/ ?>