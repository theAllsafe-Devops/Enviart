

    <!--************ FOOTER ******************** -->

    <footer class="footer dark-blue-background">
        <div class="container footer-container py-5">
            <div class="row footer-row white-color position-relative">
                <!-- FOOTER COLUMN 1  -->
                <div class="col-md-6 footer-col my-3">
                    <!-- FOOTER COLUMN HEADING  -->
                    <div class="footer-col-heading">
                        <p>Contact Us:</p>
                    </div>
                    <!-- FOOTER COLUMN TEXT  -->
                    <div class="footer-col-text">
                        <a href="mailto:uncatserver@gmail.com" class="white-color">uncatserver@gmail.com</a>
                    </div>
                </div>

                <!-- FOOTER COLUMN 2 -->
                <div class="col-md-6 footer-col my-3 text-md-end">
                    <!-- FOOTER COLUMN HEADING  -->
                    <div class="footer-col-heading">
                        <p>Reach us at Tandemhive Global</p>
                    </div>
                    <!-- FOOTER COLUMN TEXT  -->
                    
                </div>
                <div class="footer-copyright mt-3 col-12">
                    <div class="copyright-content d-flex align-items-center justify-content-center">
                        <div class="copyright-text">
                            <p class="white-color m-0">Powered by - </p>
                        </div>
                        <div class="copyright-image-outer">
                            <img src="media/christ.png" alt="" class="copyright-img img-fluid ms-2">
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </footer>



    <!--************ FOOTER END ******************** -->


<?php /**PATH F:\xamp\htdocs\laravel\uncatadmin\resources\views/admin/include/footer.blade.php ENDPATH**/ ?>