<aside class="main-sidebar">
    <!-- sidebar-->
    <section class="sidebar" style="height: auto;">
		  
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="image"><?php $data=DB::table('users')->where('id',Auth::user()->id)->first(); ?>
          <img src="<?php if($data->profile_image): ?> <?php echo e(URL::asset('admin_assets/upload')); ?>/<?php echo e($data->profile_image); ?> <?php else: ?> <?php echo e(URL::asset('admin_assets/images/logo-big.png')); ?> <?php endif; ?>" class="rounded-circle" alt="User Image">
        </div>
        <div class="info">
        </div>
      </div>
      
      <!-- sidebar menu-->
      <ul class="sidebar-menu tree" data-widget="tree">
		<li><a href="<?php echo e(URL::asset('admin/dashboard')); ?>"><i class="ti-dashboard"></i>Dashboard</a></li>
		   
        <li class="treeview">
          <a href="#">
            <i class="ti-view-list"></i>
			<span>Partner Management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(URL::asset('admin/partner')); ?>">Partner List</a></li>
            <li><a href="<?php echo e(URL::asset('admin/partner/create')); ?>">Create Partner</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="ti-view-list"></i>
			<span>Admin Management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(URL::asset('admin/admin')); ?>">Admin List</a></li>
            <li><a href="<?php echo e(URL::asset('admin/admin/create')); ?>">Create Admin</a></li>
          </ul>
        </li> 
        <li class="treeview">
          <a href="#">
            <i class="ti-view-list"></i>
			<span>App Management</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(URL::asset('admin/student/list')); ?>">Student List</a></li>
          </ul>
        </li>
        
      </ul>
    </section>
  </aside><?php /**PATH /home3/scsyin/public_html/schoolbuddy/schoolbuddy/resources/views/admin/include/siderbar.blade.php ENDPATH**/ ?>