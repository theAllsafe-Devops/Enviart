<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UnCAT - Assessment Tool</title>

    <link rel="shortcut icon" href="<?php echo e(URL::asset('admin_assets/media/logo.ico')); ?>" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
                  integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x"
                  crossorigin="anonymous">
    <!-- <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <link rel="stylesheet" href="css/animate.css"> -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css"> -->
    <!-- <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('admin_assets/css/style.css')); ?>">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap"
                  rel="stylesheet">
    <script src="https://kit.fontawesome.com/60a5beb53e.js" crossorigin="anonymous"></script>
</head>

<body>

    <!--************ NAVBAR ******************** -->

    <nav class="navbar navbar-expand-md navbar-light position-relative" id="header">
        <div class="container nav-container">
            <!-- NAVBAR BRAND  -->
            <a class="navbar-brand pl-2 pl-md-0" href="index.html">
                <img src="<?php echo e(URL::asset('admin_assets/media/uncat_logo.png')); ?>"" alt="" class="logo-img img-responsive">
            </a>

            <!-- NAVBAR LINKS  -->
            <div class=" justify-content-end">
                <ul class="navbar-nav nav ml-auto black-clr">
                    <!-- NAV ITEM  -->
                    <!-- <li class="nav-item px-2 px-lg-3">
                        <a class="nav-link button white-color orange-background px-4 px-sm-5 f-semi-bold py-1"
                                      href="index.html">Logout <span class="sr-only">(current)</span></a>
                    </li> -->
                </ul>

            </div>
        </div>
    </nav>
    <!--************ NAVBAR END ******************** -->


    <!--************ LOGIN ******************** -->

    <div class="login container my-5">
        <div class="row login-row">
            <!-- LOGIN COLUMN 1  -->
            <div class="col-md-6 login-col my-3 d-none d-md-flex align-items-center justify-content-center">
                <img src="<?php echo e(URL::asset('admin_assets/media/login-banner.png')); ?>" alt="" class="login-img img-fluid">
            </div>

            <!-- LOGIN COLUMN 2 -->
            <div class="col-md-6 login-col my-3">
                <div class="login-signup-box m-auto">
                    <div class="login-heading my-3">
                        <h3 class="f-semi-bold dark-blue-color">
                            Log In
                        </h3>
                    </div>
                    <?php if(session()->has('error')): ?>
					<div class="alert alert-danger">
							<?php echo e(session()->get('error')); ?>

						</div>
					<?php endif; ?>
                    <form action="<?php echo e(url('clientmakelogin')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group my-3">
                            <input type="text"  name="email" class="form-control login-signup-input py-3 orange-color" id="" aria-describedby=""
                                          placeholder="Username" required>
                        </div>
                        <div class="form-group mt-3 mb-4">
                            <input type="password" name="password" class="form-control login-signup-input py-3 orange-color" id="" placeholder="Password" required>
                        </div>
                       
                        <button type="submit" class="button f-semi-bold orange-background login-signup-btn w-100 py-3">Login</button>
                    </form>
                    <div class="issue-text mt-2 text-center dark-blue-color">
                        <p>For any issue mail us at <a href="mailto:info@uncat.in" class="dark-blue-color">info@uncat.in</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    



    <!--************ LOGIN END ******************** -->




    <!--************ FOOTER ******************** -->

    <footer class="footer dark-blue-background">
        <div class="container footer-container py-5">
            <div class="row footer-row white-color position-relative">
                <!-- FOOTER COLUMN 1  -->
                <div class="col-md-6 footer-col my-3">
                    <!-- FOOTER COLUMN HEADING  -->
                    <div class="footer-col-heading">
                        <p>Contact Us:</p>
                    </div>
                    <!-- FOOTER COLUMN TEXT  -->
                    <div class="footer-col-text">
                        <a href="mailto:uncatserver@gmail.com" class="white-color">uncatserver@gmail.com</a>
                    </div>
                </div>

                <!-- FOOTER COLUMN 2 -->
                <div class="col-md-6 footer-col my-3 text-md-end">
                    <!-- FOOTER COLUMN HEADING  -->
                    <div class="footer-col-heading">
                        <p>Reach us at Tandemhive Global</p>
                    </div>
                    <!-- FOOTER COLUMN TEXT  -->
                    
                </div>
                <div class="footer-copyright mt-3 col-12">
                    <div class="copyright-content d-flex align-items-center justify-content-center">
                        <div class="copyright-text">
                            <p class="white-color m-0">Powered by - </p>
                        </div>
                        <div class="copyright-image-outer">
                            <img src="media/christ.png" alt="" class="copyright-img img-fluid ms-2">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>



    <!--************ FOOTER END ******************** -->




    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
                  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
                  integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
                  crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"
                  integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT"
                  crossorigin="anonymous"></script>
    <!-- <script src="js/wow.min.js"></script>
    <script src="js/owl.carousel.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script> -->
    <!-- <script data-cfasync="false" type="text/javascript" src="js/form-submission-handler.min.js" defer></script> -->
    <script type="text/javascript" src="<?php echo e(URL::asset('admin_assets/js/script.js')); ?>"></script>
</body>

</html><?php /**PATH /home/bittaskc/public_html/uncat/uncatadmin/resources/views/clientlogin.blade.php ENDPATH**/ ?>