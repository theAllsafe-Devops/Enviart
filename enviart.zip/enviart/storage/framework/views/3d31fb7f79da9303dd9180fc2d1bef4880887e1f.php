
<?php $__env->startSection('content'); ?>

    <!--************ ADD-CLIENT ******************** -->

    <div class="container add-client my-5">
        <!-- ADD-CLIENT HEADING  -->
        <div class="section-heading instructions-main-heading dark-blue-color mb-3 text-center">
            <h1 class="f-bold">
                Edit Question
            </h1>
        </div>
        <?php if(session()->has('status')): ?>
		<div class="alert alert-info">
				<?php echo e(session()->get('status')); ?>

			</div>
		<?php endif; ?>
        <form class="add-client-form my-5" action="<?php echo e(url('question/update/')); ?>/<?php echo e($users['id']); ?>" method="POST">
             <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('PUT')); ?>

           <div class="d-block d-md-flex justify-content-between align-items-center">
                <div class="form-group my-3 w-100 d-flex justify-content-center">
                    <input type="text" class="form-control login-signup-input add-client-input py-3 orange-color"
                                  id="" aria-describedby="" placeholder="New Serial Number" required name="new_serial_number"  value="<?php echo e($users['new_serial_number']); ?>">
                </div>
                <div class="form-group my-3 w-100 d-flex justify-content-center">
                    <input type="text"
                                  class="form-control login-signup-input add-client-input py-3 orange-color "
                                  id="" placeholder="Old Serial Number" required name="old_serial_number" value="<?php echo e($users['old_serial_number']); ?>">
                </div>
            </div>
            <div class="d-block d-md-flex justify-content-between align-items-center">
                <div class=" my-3 w-100 d-flex justify-content-center">
                    <select class="form-select login-signup-input add-client-input py-3 dark-blue-color" aria-label="Default select example" name="question_section">
                        <option selected>Select Question Section</option>
                        <option value="Gender Bias" <?php if($users['question_section']=="Gender Bias"): ?> selected <?php endif; ?>>A-Gender Bias</option>
                        <option value="Regional Bias" <?php if($users['question_section']=="Regional Bias"): ?> selected <?php endif; ?>>B-Regional Bias</option>
                        <option value="Religious Bias" <?php if($users['question_section']=="Religious Bias"): ?> selected <?php endif; ?>>C-Religious Bias</option>
                        <option value="Fundamental Attribution Error" <?php if($users['question_section']=="Fundamental Attribution Error"): ?> selected <?php endif; ?>>D-Fundamental Attribution Error</option>
                        <option value="Hostile Attribution Error" <?php if($users['question_section']=="Hostile Attribution Error"): ?> selected <?php endif; ?>>E-Hostile Attribution Error</option>
                        <option value="F-Ageism" <?php if($users['question_section']=="F-Ageism"): ?> selected <?php endif; ?>>F-Ageism</option>
                        <option value="Actor Observer Bias" <?php if($users['question_section']=="Actor Observer Bias"): ?> selected <?php endif; ?>>G-Actor Observer Bias</option>
                        <option value="Self-serving Bias" <?php if($users['question_section']=="Self-serving Bias"): ?> selected <?php endif; ?>>H-Self-serving Bias</option>
                        <option value="LGBTQIA+ Bias" <?php if($users['question_section']=="LGBTQIA+ Bias"): ?> selected <?php endif; ?>>I-LGBTQIA+ Bias</option>
                        <option value="Ultimate Attribute error" <?php if($users['question_section']=="Ultimate Attribute error"): ?> selected <?php endif; ?>>J-Ultimate Attribute error</option>
                        <option value="Affinity Bias" <?php if($users['question_section']=="Affinity Bias"): ?> selected <?php endif; ?>>K-Affinity Bias</option>
                        <option value="Beauty Bias" <?php if($users['question_section']=="Beauty Bias"): ?> selected <?php endif; ?>>L-Beauty Bias</option>
                        <option value="Ableism" <?php if($users['question_section']=="Ableism"): ?> selected <?php endif; ?>>M-Ableism</option>
                        <option value="Confirmation Bias" <?php if($users['question_section']=="Confirmation Bias"): ?> selected <?php endif; ?>>N-Confirmation Bias</option>
                        <option value="Conformity Bias" <?php if($users['question_section']=="Conformity Bias"): ?> selected <?php endif; ?>>O-Conformity Bias</option>
                        <option value="Contrast Bias" <?php if($users['question_section']=="Contrast Bias"): ?> selected <?php endif; ?>>P-Contrast Bias</option>
                        <option value="Halo Effect" <?php if($users['question_section']=="Halo Effect"): ?> selected <?php endif; ?>>Q-Halo Effect</option>
                        <option value="Horn Effect" <?php if($users['question_section']=="Horn Effect"): ?> selected <?php endif; ?>>R-Horn Effect</option>
                      </select>
                </div>
                <div class=" my-3 w-100 d-flex justify-content-center">
                    <select class="form-select login-signup-input add-client-input py-3 dark-blue-color" aria-label="Default select example" name="score_type">
                        <option selected>Select Score Type</option>
                        <option value="1" <?php if($users['score_type']==1): ?> selected <?php endif; ?>>Direct Score</option>
                        <option value="2" <?php if($users['score_type']==2): ?> selected <?php endif; ?>>Reverse Score</option>
                        <option value="3" <?php if($users['score_type']==3): ?> selected <?php endif; ?>>SDQ</option>
                      </select>
                </div>
            </div>
            <div class="d-block d-md-flex justify-content-between align-items-center">
                <div class=" my-3 w-100 d-flex justify-content-center">
                    <textarea class="form-control login-signup-input add-client-text-area px-0 py-3 dark-blue-color px-2"  name="your_question" id="exampleFormControlTextarea1" rows="4" placeholder="Type Your Question"> <?php echo e($users['your_question']); ?></textarea>
                </div>
            </div>
            

            <div class="submit-btn-outer text-center my-5">
                <button type="submit" class="button f-semi-bold dark-blue-background white-color login-signup-btn add-client-btn py-3">Submit</button>
            </div>
        </form>
    </div>



    <!--************ ADD-CLIENT END ******************** -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bittaskc/public_html/uncat/uncatadmin/resources/views/admin/question/edit.blade.php ENDPATH**/ ?>