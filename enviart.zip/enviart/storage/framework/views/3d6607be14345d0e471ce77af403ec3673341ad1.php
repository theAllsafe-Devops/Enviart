
<?php $__env->startSection('mainarea'); ?>
	<!-- jQuery UI 1.11.4 -->
	<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/jquery-ui/jquery-ui.js')); ?>"></script>
	
	<!-- popper -->
	<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/popper/dist/popper.min.js')); ?>"></script>
<div class="content-wrapper" style="min-height: 1823.48px;">
	  <div class="container-full">
		<!-- Content Header (Page header) -->
		<div class="content-header">
			<div class="d-flex align-items-center">
				<div class="mr-auto">
					<h3 class="page-title"><?php echo e($page['page_name']); ?></h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item" aria-current="page"><?php echo e($page['page_name']); ?></li>
								<li class="breadcrumb-item active" aria-current="page">Create <?php echo e($page['page_name']); ?></li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
        
		<!-- Main content -->
		<section class="content">

		  <div class="row">

			<div class="col-12">
			  <div class="box">
				  
				<div class="box-header">
					<h4 class="box-title"><?php echo e($page['page_name']); ?></h4>  
				</div>
				<?php if(session()->has('status')): ?>
        		<div class="alert alert-info">
        				<?php echo e(session()->get('status')); ?>

        			</div>
        		<?php endif; ?>
        		<?php if($errors->any()): ?>
        		<div class="alert alert-info">
        				<?php echo e(implode('', $errors->all(':message'))); ?>

        			</div>
        		<?php endif; ?>
				<div class="box-body">
				    <form novalidate action="<?php echo e(url('admin/banner/store')); ?>" method="POST" enctype="multipart/form-data">
				        <?php echo csrf_field(); ?>
					<div class="form-group row">
						<label class="col-form-label col-md-2">Image</label>
						<div class="col-md-10">
							<div class="controls">
								<input type="file" name="image" class="form-control" required data-validation-required-message="This field is required"> 
							</div>
						</div>
					</div>	
					<div class="form-group row">
						<label class="col-form-label col-md-2">Title</label>
						<div class="col-md-10">
						    <div class="controls">
							<input class="form-control" type="text" name="title" placeholder="Title" required data-validation-required-message="This field is required">
						    </div>
						</div>
					</div>
					<div class="form-group">
						<label>Description</label>
						<textarea rows="5" cols="5" class="form-control" name="description" placeholder="Description"></textarea>
					</div>
					<div class="text-xs-right">
						<button type="submit" class="btn btn-info">Submit</button>
					</div>
					</form>
				</div>
				<!-- /.box-body -->
			  </div>
			  <!-- /.box -->
			</div>
			<!-- ./col -->
		  </div>
		  <!-- /.row -->
		</section>
		<!-- /.content -->
	  </div>
  </div>
<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/jquery-3.3.1/jquery-3.3.1.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/pages/validation.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/pages/form-validation.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/scsyin/public_html/spiritualIndia/resources/views/admin/banner/create.blade.php ENDPATH**/ ?>