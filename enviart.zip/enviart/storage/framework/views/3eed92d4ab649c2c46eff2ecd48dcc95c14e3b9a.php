<html>
    Email : <span><?php echo e($email); ?></span><br>
    Password : <span><?php echo e($password); ?></span><br>
    <p>Test Can be taken between Start-End Date</p><br>
    Starting Date : <span><?php echo e($starting_Date); ?></span><br>
    ClosingDate : <span><?php echo e($closing_Date); ?></span><br>
</html><?php /**PATH /home/bittaskc/public_html/uncat/uncatadmin/resources/views/admin/mail.blade.php ENDPATH**/ ?>