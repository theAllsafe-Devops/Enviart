
<?php $__env->startSection('mainarea'); ?>
<div class="content-wrapper" style="min-height: 1823.48px;">
	  <div class="container-full">
		<!-- Content Header (Page header) -->
		<div class="content-header">
			<div class="d-flex align-items-center">
				<div class="mr-auto">
					<h3 class="page-title">Authentication</h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item" aria-current="page">Authentication</li>
								<li class="breadcrumb-item active" aria-current="page">Edit Student</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
        
		<!-- Main content -->
		<section class="content">

		  <div class="row">

			<div class="col-12">
			  <div class="box">
				  
				<div class="box-header">
					<h4 class="box-title">Edit Student</h4>  
				</div>
				<?php if(session()->has('status')): ?>
        		<div class="alert alert-info">
        				<?php echo e(session()->get('status')); ?>

        			</div>
        		<?php endif; ?>
        		<?php if($errors->has('email')): ?>
        		<div class="alert alert-danger">
    				<?php echo e($errors->first('email')); ?>

    			</div>
        		<?php endif; ?>
				<div class="box-body">
				    <form novalidate action="<?php echo e(url('partner/student/update/')); ?>/<?php echo e($student['id']); ?>" method="POST">
				        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

					<div class="form-group row">
						<label class="col-form-label col-md-2">Choose session</label>
						<div class="col-md-10">
						    <div class="controls">
						        <select class="form-control" name="session" required data-validation-required-message="This field is required">
						        <?php $__currentLoopData = $session; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							    <option <?php if($row->session==$student1->session){ echo "selected"; } ?>><?php echo e($row->session); ?></option>
							    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							    </select>
						    </div>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-form-label col-md-2">Choose Class</label>
						<div class="col-md-10">
						    <div class="controls">
						        <select class="form-control" name="class" required data-validation-required-message="This field is required">
						        <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							    <option <?php if($row->class==$student1->class){ echo "selected"; } ?>><?php echo e($row->class); ?></option>
							    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							    </select>
						    </div>
						</div>
					</div>

					<div class="form-group row">
						<label class="col-form-label col-md-2">Student Name</label>
						<div class="col-md-10">
						    <div class="controls">
							<input class="form-control" type="text" value="<?php echo e($student['name']); ?>" name="name" required data-validation-required-message="This field is required">
						    </div>
						</div>
					</div>

					<div class="form-group row">
						<label class="col-form-label col-md-2">Email( login id)</label>
						<div class="col-md-10">
							<div class="controls">
								<input type="email" name="email" value="<?php echo e($student['email']); ?>" class="form-control" required data-validation-required-message="This field is required"> 
							</div>
						</div>
					</div>	
					<div class="form-group row">
						<label class="col-form-label col-md-2">Student Contact Number</label>
						<div class="col-md-10">
							<div class="controls">
								<input type="number" name="contact_number" value="<?php echo e($student1['contact_number']); ?>" class="form-control" required data-validation-required-message="This field is required"> 
							</div>
						</div>
					</div>	
					<div class="text-xs-right">
						<button type="submit" class="btn btn-info">Update</button>
					</div>
					</form>
				</div>
				<!-- /.box-body -->
			  </div>
			  <!-- /.box -->
			</div>
			<!-- ./col -->
		  </div>
		  <!-- /.row -->
		</section>
		<!-- /.content -->
	  </div>
  </div>
  <script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/jquery-3.3.1/jquery-3.3.1.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/pages/validation.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/pages/form-validation.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partner.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/scsyin/public_html/schoolbuddy/uncatadmin/resources/views/partner/student/edit.blade.php ENDPATH**/ ?>