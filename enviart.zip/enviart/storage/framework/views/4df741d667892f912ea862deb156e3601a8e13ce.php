<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <?php echo $__env->make('admin.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
	<body class="app sidebar-mini light-mode default-sidebar">
		<!---Global-loader-->
		<!-- <div id="global-loader" >
			<img src="<?php echo e(URL::asset('admin_assets/images/svgs/loader.svg')); ?>" alt="loader">
		</div> -->

		<div class="page">
            <div class="page-main">
				<!--aside open-->				
				<?php echo $__env->make('admin.include.siderbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('mainarea'); ?>
            </div><!-- End Page -->
                <!--Footer-->
                <footer class="footer">
                    <div class="container">
                        <div class="row align-items-center flex-row-reverse">
                            <div class="col-md-12 col-sm-12 mt-3 mt-lg-0 text-center">
                                Copyright © 2020 <a href="#">Dashtic</a>. Designed by <a href="#">Spruko Technologies Pvt.Ltd</a> All rights reserved.
                            </div>
                        </div>
                    </div>
                </footer><!-- End Footer-->
        </div><!-- End Page -->
<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\laravel\theallsafe\resources\views/admin/include/layout.blade.php ENDPATH**/ ?>