<?php $__env->startSection('content'); ?>
    <!--************ VIEW CLIENT ******************** -->

    <div class="container view-client my-5">
        <!-- VIEW CLIENT HEADING  -->
        <div class="section-heading instructions-main-heading dark-blue-color mb-3 text-center">
            <h1 class="f-bold">
                View Clients
            </h1>
        </div>

        <!-- CLIENT CARDS  -->
        <div class="row view-client-row my-5">
            <!-- CLIENT COLUMN 1  --><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4 view-client-col p-3">
                <div class="card address-card m-auto">
                    <!-- CLIENT CARD CONTENT  -->
                    <div class="card-body address-card-body">
                        <p class="client-card-head f-semi-bold dark-blue-color">
                            Client ID: <span class="client-card-text orange-color f-normal ms-2"><?php echo e(++$key); ?></span>
                        </p>
                        <p class="client-card-head f-semi-bold dark-blue-color">
                            Client Name: <span class="client-card-text orange-color f-normal ms-2"><?php echo e($i->name); ?></span>
                        </p>
                        <p class="client-card-head f-semi-bold dark-blue-color">
                            Age: <span class="client-card-text orange-color f-normal ms-2"><?php echo e($i->age); ?></span>
                        </p>
                        <p class="client-card-head f-semi-bold dark-blue-color">
                            Mobile Number: <span class="client-card-text orange-color f-normal ms-2"><?php echo e($i->phone); ?></span>
                        </p>
                        <p class="client-card-head f-semi-bold dark-blue-color">
                            Years of Experience: <span class="client-card-text orange-color f-normal ms-2"><?php echo e($i->years_of_experience); ?></span>
                        </p>
                        <p class="client-card-head f-semi-bold dark-blue-color">
                            Educational Qualification: <span
                                          class="client-card-text orange-color f-normal ms-2"><?php echo e($i->qualification); ?></span>
                        </p>
                    </div>
                    <!-- CLIENT EDIT LINKS  -->
                    <div class="client-edit-links d-flex align-baseline justify-content-between">
                        <div class="client-links-inner px-3 mb-3">
                            <a href=<?php echo e("client/edit/".$i->id); ?> class="edit-client px-1 black-color">Edit</a>
                        </div>
                        <div class="client-links-inner px-3 mb-3">
                            <a href=<?php echo e("client/destroy/".$i->id); ?> class="delete-client px-1">Delete</a>
                        </div>
                    </div>
                </div>
                
            </div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </div>
    </div>
    <!--************ VIEW CLIENT END ******************** -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bittaskc/public_html/uncat/uncatadmin/resources/views/admin/client/index.blade.php ENDPATH**/ ?>