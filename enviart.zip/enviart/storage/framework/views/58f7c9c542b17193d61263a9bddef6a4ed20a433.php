
<?php $__env->startSection('mainarea'); ?>
<div class="content-wrapper" style="min-height: 1823.48px;">
	  <div class="container-full">
		<!-- Content Header (Page header) -->
		<div class="content-header">
			<div class="d-flex align-items-center">
				<div class="mr-auto">
					<h3 class="page-title">Video </h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item" aria-current="page">Video </li>
								<li class="breadcrumb-item active" aria-current="page">Edit Video </li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
        
		<!-- Main content -->
		<section class="content">

		  <div class="row">

			<div class="col-12">
			  <div class="box">
				  
				<div class="box-header">
					<h4 class="box-title">Edit Video </h4>  
				</div>
				<?php if(session()->has('status')): ?>
        		<div class="alert alert-info">
        				<?php echo e(session()->get('status')); ?>

        			</div>
        		<?php endif; ?>
				<div class="box-body">
				    <form novalidate action="<?php echo e(url('admin/video/update/')); ?>/<?php echo e($vedio['id']); ?>" method="POST" enctype="multipart/form-data">
				        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

                        <div class="form-group row">
    						<label class="col-form-label col-md-2">Name</label>
    						<div class="col-md-10">
    						    <div class="controls">
    							<input class="form-control" type="text"  value="<?php echo e($vedio['name']); ?>" name="name" placeholder="Name"  required data-validation-required-message="This field is required">
    						    </div>
    						</div>
    					</div>
					<div class="form-group row">
						<label class="col-form-label col-md-2">Program Name</label>
						<div class="col-md-10">
						    <div class="controls">
							<select class="form-control" name="category_name" required data-validation-required-message="This field is required">
							    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							    <option value="<?php echo e($category_val->id); ?>" <?php if($category_val->id==$vedio->category_id): ?> selected <?php endif; ?>><?php echo e($category_val->category_name); ?></option>
							    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						    </div>
						</div>
					</div>

					<div class="form-group row">
						<label class="col-form-label col-md-2">Video</label>
						<div class="col-md-10">
							<div class="controls">
								<input type="hidden" name="oldimage" class="form-control" value="<?php echo e($vedio['vedio']); ?>"> 
								<input type="file" name="vedio" class="form-control"> 
							</div>
						</div>
					</div>	
					<div class="form-group">
						<label>Description	</label>
						<textarea rows="5" cols="5" class="form-control" name="dsc" placeholder="Description"><?php echo e($vedio['dsc']); ?></textarea>
					</div>
					<div class="text-xs-right">
						<button type="submit" class="btn btn-info">Submit</button>
					</div>
					</form>
				</div>
				<!-- /.box-body -->
			  </div>
			  <!-- /.box -->
			</div>
			<!-- ./col -->
		  </div>
		  <!-- /.row -->
		</section>
		<!-- /.content -->
	  </div>
  </div>
  <script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/jquery-3.3.1/jquery-3.3.1.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/pages/validation.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/pages/form-validation.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/scsyin/public_html/gym/resources/views/admin/vediouploade/edit.blade.php ENDPATH**/ ?>