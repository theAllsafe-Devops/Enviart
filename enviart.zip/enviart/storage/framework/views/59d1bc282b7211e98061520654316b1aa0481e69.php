<footer class="main-footer">
	  Developed by By <a href="www.friendzitsolutions.biz">Friendz IT Solutions</a>
  </footer><?php /**PATH /home3/scsyin/public_html/gym/resources/views/admin/include/footer.blade.php ENDPATH**/ ?>