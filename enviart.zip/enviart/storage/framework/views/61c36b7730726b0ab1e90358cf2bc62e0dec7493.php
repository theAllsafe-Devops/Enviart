<aside class="main-sidebar">
    <!-- sidebar-->
    <section class="sidebar" style="height: auto;">
		  
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="image"><?php $data=DB::table('users')->where('id',Auth::user()->id)->first(); ?>
          <img src="<?php if($data->profile_image): ?> <?php echo e(URL::asset('admin_assets/upload')); ?>/<?php echo e($data->profile_image); ?> <?php else: ?> <?php echo e(URL::asset('admin_assets/images/logo-big.png')); ?> <?php endif; ?>" class="rounded-circle" alt="User Image">
        </div>
        <div class="info">
        </div>
      </div>
      
      <!-- sidebar menu-->
      <ul class="sidebar-menu tree" data-widget="tree">
		<li><a href="<?php echo e(URL::asset('admin/dashboard')); ?>"><i class="ti-dashboard"></i>Dashboard</a></li>
		<li><a href="<?php echo e(URL::asset('admin/banner')); ?>"><i class="ti-view-list"></i>Banners</a></li>
		<li><a href="<?php echo e(URL::asset('admin/services')); ?>"><i class="ti-view-list"></i>Services</a></li>
		<li><a href="<?php echo e(URL::asset('admin/dashboard')); ?>"><i class="ti-view-list"></i>Latest news</a></li>
		<li><a href="<?php echo e(URL::asset('admin/gallery')); ?>"><i class="ti-view-list"></i>Gallery</a></li>
		<li><a href="<?php echo e(URL::asset('admin/dashboard')); ?>"><i class="ti-view-list"></i>Contact us</a></li>
		<li><a href="<?php echo e(URL::asset('admin/dashboard')); ?>"><i class="ti-view-list"></i>Service enquiry</a></li>

      </ul>
    </section>
  </aside><?php /**PATH /home3/scsyin/public_html/spiritualIndia/resources/views/admin/include/siderbar.blade.php ENDPATH**/ ?>