<!DOCTYPE html>
<html>
<body>

<h1>Your Trail Period is Over now.</h1>

<?php
echo "Please Contact Sales!";
?> 

</body>
</html><?php /**PATH /home/blueczur/gulfbills.com/demo/resources/views/admin/login.blade.php ENDPATH**/ ?>