    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo e(URL::asset('admin_assets/images/favicon.ico')); ?>">

    <title>Admin - Dashboard</title>
    
	<!-- Bootstrap 4.0-->
	<link rel="stylesheet" href="<?php echo e(URL::asset('admin_assets/assets/vendor_components/bootstrap/dist/css/bootstrap.css')); ?>">
	
	<!-- daterange picker -->	
	<link rel="stylesheet" href="<?php echo e(URL::asset('admin_assets/assets/vendor_components/bootstrap-daterangepicker/daterangepicker.css')); ?>">	
	
	<!-- weather weather -->
	<link rel="stylesheet" href="<?php echo e(URL::asset('admin_assets/assets/vendor_components/weather-icons/weather-icons.css')); ?>">	
	
	<!-- Data Table-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('admin_assets/assets/vendor_components/datatable/datatables.min.css')); ?>"/>	
		
	<!-- Bootstrap extend-->
	<link rel="stylesheet" href="<?php echo e(URL::asset('admin_assets/css/bootstrap-extend.css')); ?>">
	
	<!-- theme style -->
	<link rel="stylesheet" href="<?php echo e(URL::asset('admin_assets/css/master_style.css')); ?>">
	
	<!-- Ekan Admin skins -->
	<link rel="stylesheet" href="<?php echo e(URL::asset('admin_assets/css/skins/_all-skins.css')); ?>">
	
<?php /**PATH /home3/scsyin/public_html/callrecording/resources/views/admin/include/head.blade.php ENDPATH**/ ?>