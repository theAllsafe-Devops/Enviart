
    <!--************ NAVBAR ******************** -->

    <nav class="navbar  navbar-light position-relative" id="header">
        <div class="container nav-container">
            <!-- NAVBAR BRAND  -->
            <a class="navbar-brand pl-2 pl-md-0" href="index.html">
                <img src="media/uncat_logo.png" alt="" class="logo-img img-responsive">
            </a>

            <!-- toggler icon  -->
            <button class="navbar-toggler" onclick="openNav()" type="button">

                <span><i class="fas fa-bars"></i></span>
            </button>
        </div>
    </nav>
    <!--************ NAVBAR END ******************** --><?php /**PATH /home/bittaskc/public_html/uncat/uncatadmin/resources/views/admin/include/header.blade.php ENDPATH**/ ?>