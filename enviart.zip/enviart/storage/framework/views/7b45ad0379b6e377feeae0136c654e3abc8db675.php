
<?php $__env->startSection('mainarea'); ?>
<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/jquery-3.3.1/jquery-3.3.1.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/popper/dist/popper.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/pages/data-table.js')); ?>"></script>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
	  <div class="container-full">
		<!-- Content Header (Page header) -->
		<div class="content-header">
			<div class="d-flex align-items-center">
				<div class="mr-auto">
					<h3 class="page-title">List</h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item" aria-current="page">List</li>
								<li class="breadcrumb-item active" aria-current="page">Partner List</li>
							</ol>
						</nav>
					</div>
				</div>
				<div class="right-title">
				</div>
			</div>
		</div>

		<!-- Main content -->
		<section class="content">
		  <div class="row">
			  
			<div class="col-12">
				<div class="box">
					<div class="box-header">						
						<h4 class="box-title">Partner List</h4>
					</div>
					<?php if(session()->has('status')): ?>
            		<div class="alert alert-info">
            				<?php echo e(session()->get('status')); ?>

            			</div>
            		<?php endif; ?>
					<div class="box-body">
						<div class="table-responsive">
							<table id="example" class="table table-bordered table-hover display nowrap margin-top-10 w-p100 dataTable" role="grid" aria-describedby="example_info">
								<thead>
									<tr>
										<th>ID</th>
										<th>Institue Name</th>
										<th>Email( login id)</th>
										<th>State.</th>
										<th>District</th>
										<th>City</th>
										<th>Pincode</th>
										<th>Action</th>
										<th>Status</th>
									</tr>
								</thead>
								<tbody><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e(++$key); ?></td>
										<td><?php echo e($value->name); ?></td>
										<td><?php echo e($value->email); ?></td>
										<td><?php echo e($value->state); ?></td>
										<td><?php echo e($value->district); ?></td>
										<td><?php echo e($value->city); ?></td>
										<td><?php echo e($value->pincode); ?></td>
										<td><a class="btn btn-outline btn-success mb-5" href="<?php echo e(url('admin/partner/edit')); ?>/<?php echo e($value->id); ?>"><i class="fa fa-edit"></i></a>
                    						<a class="btn btn-outline btn-success mb-5" href="<?php echo e(url('admin/partner/destroy')); ?>/<?php echo e($value->id); ?>" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fa fa-trash-o"></i></a>
                    					</td>
                    					<td>
                    					    <select class="change_status login_status-<?php echo e($value->id); ?>" data-id="<?php echo e($value->id); ?>">
                    					    <option value="1" <?php if($value->login_status==1): ?> selected <?php endif; ?>>Enable</option>
                    					    <option value="0" <?php if($value->login_status==0): ?> selected <?php endif; ?>>Disable</option>
                    					    </select>
                    					</td>
									</tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
					</table>
					</div>              
				</div>
				<!-- /.box-body -->
			  </div>
			  <!-- /.box -->          
			</div>
			<!-- /.col -->
		  </div>
		  <!-- /.row -->
		</section>
		<!-- /.content -->
	  
	  </div>
  </div>
  <!-- /.content-wrapper -->
<!-- Data Table-->
<script>
 $(document).ready(function(){
     $('.change_status').on('change',function(){
        var id = $(this).attr("data-id"); 
        var status = $('.login_status-'+id).val();
        // alert(id+status);
        $.ajax({
        type: "post",
        dataType: "json",
        url: "<?php echo e(URL::asset('admin/partner/status')); ?>",
        data: { _token:'<?php echo e(csrf_token()); ?>','id':id,'status':status},

        success: function (response) {
           if(response=='0')
		    {
		        alert("Status update successfully");
			    location.reload();  
		    }
		    else{
		        alert("Status not update");
		    }
        }
        });
    	
    });
 });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/scsyin/public_html/schoolbuddy/schoolbuddy/resources/views/admin/partner/index.blade.php ENDPATH**/ ?>