
<?php $__env->startSection('mainarea'); ?>
<script src="<?php echo e(URL::asset('public/assets/js/plugins/datatables.js')); ?>"></script>
<div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card">
              <?php if(session()->has('delete')): ?>
                    <div class="alert alert-success" role="alert">
                      <strong>Success!</strong> <?php echo e(session()->get('delete')); ?>

                  `</div>
            	<?php endif; ?>
            <!-- Card header -->
            <div class="card-header pb-0">
              <div class="d-lg-flex">
                <div  <?php if(session('type')==0): ?>   class="ms-auto my-auto mt-lg-0 mt-4"   <?php endif; ?>>
                  <h5 class="mb-0"><?php if(session('type')==0): ?>  الفواتير <?php else: ?>  Invoice <?php endif; ?></h5>
                  
                </div>
                <div class="<?php if(session('type')==0): ?>    <?php else: ?>  ms-auto <?php endif; ?> my-auto mt-lg-0 mt-4">
                  <div class="ms-auto my-auto">
                    <!--<a href="<?php echo e(url('admin/bill/create')); ?>" class="btn bg-gradient-info btn-sm mb-0">+&nbsp; <?php if(session('type')==0): ?> مشروع قانون جديد  <?php else: ?> New Invoice <?php endif; ?> </a>-->
                    <button class="btn btn-outline-info btn-sm export mb-0 mt-sm-0 mt-1" data-type="csv" type="button" name="button"><?php if(session('type')==0): ?> تصدير   <?php else: ?> Export <?php endif; ?> </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-body px-0 pb-0">
              <div class="table-responsive">
                <table class="table table-flush" id="products-list">
                  <thead class="thead-light">
                    <tr>
                      <th><?php if(session('type')==0): ?> هوية شخصية <?php else: ?> ID <?php endif; ?>                     </th>  
                      <th><?php if(session('type')==0): ?> اسم الزبون <?php else: ?> Customer Name <?php endif; ?>              </th>
                      <th><?php if(session('type')==0): ?> نوع الدفع  <?php else: ?> Payment Type <?php endif; ?>              </th>
                      <th><?php if(session('type')==0): ?> المبلغ الإجمالي  <?php else: ?> Total Payment <?php endif; ?>                   </th>
                      <th><?php if(session('type')==0): ?> التاريخ و الوقت  <?php else: ?> date & time <?php endif; ?>                     </th>  
                      <th><?php if(session('type')==0): ?> عمل  <?php else: ?> Action <?php endif; ?>                          </th>
                    </tr>
                  </thead>
                  <tbody><?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a target="_blank" href="<?php echo e(url('admin/invoice')); ?>/<?php echo e($value->id); ?>"><?php echo e(++$key); ?></a></td>
                        
                      <td>
                        <div class="d-flex">
                          <h6 class="my-auto"><?php echo e($value->customer_name); ?></h6>
                        </div>
                      </td>
                      <td>
                        <div class="d-flex">
                          <h6 class="my-auto"><?php echo e($value->payment_type); ?></h6>
                        </div>
                      </td>
                      <td class="text-sm"><?php echo e($value->order_total_amount_due); ?></td>
                      <td class="text-sm"><?php echo e($value->created_at); ?></td>
                      <td class="text-sm">
                        <a href="<?php echo e(url('admin/bill/destroy')); ?>/<?php echo e($value->id); ?>" class="mx-3" data-bs-toggle="tooltip" data-bs-original-title="Delete product" onclick="return confirm('Are you sure you want to delete this item?');" >
                          <i class="fas fa-trash text-secondary"></i>
                        </a>
                        <!--<a href="<?php echo e(url('admin/product/destroy')); ?>/<?php echo e($value->id); ?>" onclick="return confirm('Are you sure you want to delete this item?');" data-bs-toggle="tooltip" data-bs-original-title="Delete product">-->
                        <!--  <i class="fas fa-trash text-secondary"></i>-->
                        <!--</a>-->
                        <a target="_blank" href="<?php echo e(url('admin/invoice')); ?>/<?php echo e($value->id); ?>">
                          <i class="fas fa-print text-secondary"></i>
                        </a>
                      </td>
                    </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
    if (document.getElementById('products-list')) {
      const dataTableSearch = new simpleDatatables.DataTable("#products-list", {
        searchable: true,
        fixedHeight: false,
        perPage: 7
      });

      document.querySelectorAll(".export").forEach(function(el) {
        el.addEventListener("click", function(e) {
          var type = el.dataset.type;

          var data = {
            type: type,
            filename: "soft-ui-" + type,
          };

          if (type === "csv") {
            data.columnDelimiter = "|";
          }

          dataTableSearch.export(data);
        });
      });
    };
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\demo\resources\views/admin/bill/index.blade.php ENDPATH**/ ?>