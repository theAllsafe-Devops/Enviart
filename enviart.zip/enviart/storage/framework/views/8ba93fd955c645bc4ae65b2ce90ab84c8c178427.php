
<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<!-- Jquery js-->
<script src="<?php echo e(URL::asset('admin_assets/js/vendors/jquery-3.5.1.min.js')); ?>"></script>
<!-- Data table css -->
<link href="<?php echo e(URL::asset('admin_assets/plugins/datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('admin_assets/plugins/datatable/css/buttons.bootstrap4.min.css')); ?>"  rel="stylesheet">
<link href="<?php echo e(URL::asset('admin_assets/plugins/datatable/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" />
<!-- Data tables -->
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/js/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/js/dataTables.bootstrap4.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/js/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/datatable/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/datatables.js')); ?>"></script>
				<div class="app-content main-content">
					<div class="side-app">
						<!--app header-->
                        <?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<!--/app header-->
												<!--Page header-->
						<div class="page-header">
							<div class="page-leftheader">
								<h4 class="page-title">Crypto Dashboard</h4>
							</div>
							<div class="page-rightheader ml-auto d-lg-flex d-none">
								<div class="ml-5 mb-0">
                                <a href="<?php echo e(URL::asset('subcategory/create')); ?>" class="btn btn-primary"><i class="fe fe-plus mr-2"></i>Add Sub Category</a>
								</div>
							</div>
						</div>
						<!--End Page header-->
						<!--Row-->
                        <div class="row">
							<div class="col-12">
								<div class="card">
									<div class="card-header">
										<div class="card-title">Basic DataTable</div>
									</div>
									<div class="card-body">
										<div class="table-responsive">
											<table class="table table-bordered text-nowrap" id="example1">
												<thead>
													<tr>
														<th class="wd-15p border-bottom-0">S.NO.</th>
														<th class="wd-15p border-bottom-0">image</th>
														<th class="wd-15p border-bottom-0">Category Name</th>
													</tr>
												</thead>
												<tbody><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr>
														<td><?php echo e(++$key); ?></td>
														<td><img style="width: 130px;" src="<?php echo e(URL::asset('admin_assets/upload/')); ?>/<?php echo e($i->image); ?>"></td>
														<td><?php echo e($i->Category_name); ?></td>
													</tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
												</tbody>
											</table>
										</div>
									</div>
								</div>
								<!--/div-->
							</div>
						</div>
						<!--End Row-->

					</div>
				</div><!-- end app-content-->

<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\laravel\theallsafe\resources\views/admin/subcategory/index.blade.php ENDPATH**/ ?>