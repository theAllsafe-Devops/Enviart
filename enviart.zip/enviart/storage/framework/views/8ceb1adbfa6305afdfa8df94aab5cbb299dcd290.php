<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UnCAT - Assessment Tool</title>

    <link rel="shortcut icon" href="media/logo.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
                  integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x"
                  crossorigin="anonymous">
    <!-- <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <link rel="stylesheet" href="css/animate.css"> -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css"> -->
    <!-- <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('admin_assets/css/style.css')); ?>">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap"
                  rel="stylesheet">
    <script src="https://kit.fontawesome.com/60a5beb53e.js" crossorigin="anonymous"></script>
    <style>
        li::marker{
   content: none;
}
    </style>
</head>

<body>

    <!--************ NAVBAR ******************** -->

    <nav class="navbar navbar-expand-md navbar-light position-relative" id="header">
        <div class="container nav-container">
            <!-- NAVBAR BRAND  -->
            <a class="navbar-brand pl-2 pl-md-0" href="index.html">
                <img src="<?php echo e(URL::asset('admin_assets/media/uncat_logo.png')); ?>" alt="" class="logo-img img-responsive">
            </a>

            <!-- NAVBAR LINKS  -->
            <div class=" justify-content-end">
                <ul class="navbar-nav nav ml-auto black-clr">
                    <!-- NAV ITEM  -->
                    <li class="nav-item px-2 px-lg-3">
                        <a class="nav-link button white-color orange-background px-4 px-sm-5 f-semi-bold py-1"
                                      href="index.html">Logout <span class="sr-only">(current)</span></a>
                    </li>
                </ul>

            </div>
        </div>
    </nav>
    <!--************ NAVBAR END ******************** -->


    <!--************ TEST ******************** -->

    <div class="test container my-5">
        <div class="section-heading test-main-heading dark-blue-color mb-2 text-center">
            <h1 class="f-bold">
                UnCAT
            </h1>
        </div>
        <div class="section-heading instructions-main-heading dark-blue-color mb-5 text-center">
            <h1 class="f-normal">
                Unconscious Conditioning Assessment Test
            </h1>
        </div>

        <div class="instructions-sub-heading dark-blue-color mb-1 text-start">
            <h4 class="f-normal"><strong>
                    Scale categories:&nbsp; 1-Strongly Disagree  &nbsp; 2-Disagree &nbsp; 3-Neutral &nbsp; 4-Agree &nbsp; 5-Strongly Agree</strong>
            </h4>
        </div>
        
        <form action="<?php echo e(url('savetestquestion')); ?>" method="POST">
        <!-- TEST QUESTION  -->
        
        <div class="mydivs">
           
        
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo csrf_field(); ?>
         <div>
            <div  class="instructions-backdrop light-blue-background dark-blue-color p-4 p-md-5 d-flex align-items-center my-3">
                <ol>
                    <li>
                        <!-- TEST QUESTION TEXT  -->
                        <div class="text-questions f-semi-bold">
                            <p class="m-0">
                                <?php echo e(++$key); ?>.<?php echo e($i->your_question); ?>

    
                                <!-- TEST ANSWER INPUT AREA  -->
                            <div class="answer-area d-block d-md-flex justify-content-between mt-4">
                                <div class="form-check my-2">
                                    <input type="hidden" name="ques_id[]" value="<?php echo e($i->id); ?>">
                                    <input class="form-check-input test-answer-input" type="radio" name="ans_no<?php echo e($i->id); ?>" id="flexRadioDefault1" value="1">
                                    <label class="form-check-label" for="flexRadioDefault1">
                                        1
                                    </label>
                                </div>
                                <div class="form-check my-2">
                                    <input class="form-check-input test-answer-input" type="radio" name="ans_no<?php echo e($i->id); ?>" id="flexRadioDefault1" value="2">
                                    <label class="form-check-label" for="flexRadioDefault1">
                                        2
                                    </label>
                                </div>
                                <div class="form-check my-2">
                                    <input class="form-check-input test-answer-input" type="radio" name="ans_no<?php echo e($i->id); ?>" id="flexRadioDefault1" value="3">
                                    <label class="form-check-label" for="flexRadioDefault1">
                                        3
                                    </label>
                                </div>
                                <div class="form-check my-2">
                                    <input class="form-check-input test-answer-input" type="radio" name="ans_no<?php echo e($i->id); ?>" id="flexRadioDefault1" value="4">
                                    <label class="form-check-label" for="flexRadioDefault1">
                                        4
                                    </label>
                                </div>
                                <div class="form-check my-2">
                                    <input class="form-check-input test-answer-input" type="radio" name="ans_no<?php echo e($i->id); ?>" id="flexRadioDefault1" value="5">
                                    <label class="form-check-label" for="flexRadioDefault1">
                                        5
                                    </label>
                                </div>
                            </div>
    
    
    
                            </p>
                        </div>
                    </li>
                </ol>
                
            </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</div>
        <!-- TEST BUTTONS  -->
        <div class="test-buttons d-flex align-items-center justify-content-between my-4">
           
        
            <div class="test-btn">
                <button type="button" name="prev" class="button test-btn-inner dark-blue-background white-color f-semi-bold py-3 px-5">Previous</button>
            </div>
            <div class="test-btn">
                <button type="submit" class="button test-btn-inner dark-blue-background white-color f-semi-bold py-3 px-5">Submit</button>
            </div>
            <div class="test-btn">
                <button type="button" name="next" class="button test-btn-inner dark-blue-background white-color f-semi-bold py-3 px-5">Next</button>
            </div>
        </div>
        
        </form>
    



    <!--************ INSTRUCTIONS END ******************** -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


    


<script>
    $(document).ready(function() {
    var divs = $('.mydivs>div');
    var now = 0; // currently shown div
    divs.hide().first().show(); // hide all divs except first
    $("button[name=next]").click(function() {
        divs.eq(now).hide();
        now = (now + 1 < divs.length) ? now + 1 : 0;
        divs.eq(now).show(); // show next
    });
    $("button[name=prev]").click(function() {
        divs.eq(now).hide();
        now = (now > 0) ? now - 1 : divs.length - 1;
        divs.eq(now).show(); // show previous
    });
});

</script>






    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
                  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
                  integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
                  crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"
                  integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT"
                  crossorigin="anonymous"></script>
    <!-- <script src="js/wow.min.js"></script>
    <script src="js/owl.carousel.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script> -->
    <!-- <script data-cfasync="false" type="text/javascript" src="js/form-submission-handler.min.js" defer></script> -->
    <script type="text/javascript" src="<?php echo e(URL::asset('admin_assets/js/script.js')); ?>"></script>
</body>

</html><?php /**PATH /home/bittaskc/public_html/uncat/uncatadmin/resources/views/testquestion.blade.php ENDPATH**/ ?>