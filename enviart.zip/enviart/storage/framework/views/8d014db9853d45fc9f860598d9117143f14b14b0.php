
<?php $__env->startSection('mainarea'); ?>
	<div class="container-fluid py-4">
      <div class="row">
        <div class="col-lg-9 col-12 mx-auto">
            <?php if(session()->has('status')): ?>
            <div class="alert alert-success" role="alert">
              <strong>Success!</strong> <?php echo e(session()->get('status')); ?>

          `</div>
    		<?php endif; ?>
    		<?php if($errors->any()): ?>
    		  <div class="alert alert-danger" role="alert" style="color:white;">
                  <strong>Warning!</strong>  <?php echo e(implode('', $errors->all(':message'))); ?>

              </div>
    		<?php endif; ?>
          <div class="card card-body mt-4">
            <form action="<?php echo e(url('admin/product/update/')); ?>/<?php echo e($row['id']); ?>" method="POST" enctype="multipart/form-data">
    			<?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <h6 class="mb-0"> <?php if(session('type')==0): ?> تحرير المنتج     <?php else: ?> Edit Product  <?php endif; ?></h6>
                <hr class="horizontal dark my-3">
                <label for="projectName" class="form-label"> <?php if(session('type')==0): ?>  اسم المنتج    <?php else: ?> Product Name  <?php endif; ?></label>
                <input type="text" class="form-control" name="product_name" value="<?php echo e($row['product_name']); ?>"><br>
                <label for="projectName" class="form-label"> <?php if(session('type')==0): ?>  سعر    <?php else: ?> Price  <?php endif; ?></label>
                <input type="text" class="form-control" name="price" value="<?php echo e($row['price']); ?>">
                
                <div class="d-flex justify-content-end mt-4">
                  <button type="submit" name="button" class="btn bg-gradient-info m-0 ms-2">  <?php if(session('type')==0): ?>  تحديث    <?php else: ?> Update <?php endif; ?></button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/scsyin/public_html/billprint/admin/resources/views/admin/product/edit.blade.php ENDPATH**/ ?>