   
     <!--************ SIDEBAR ******************** -->
       

        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

            <!-- SIDEBAR ITEM  -->
            <a href="<?php echo e(url('dashboard')); ?>" class="dark-blue-color side-nav-item">Admin Dashboard</a>
            <hr>

            <!-- SIDEBAR ITEM  -->
            <a href="<?php echo e(url('client/create')); ?>" class="dark-blue-color side-nav-item">Add Client</a>
            <hr>

            <!-- SIDEBAR ITEM  -->
            <a href="<?php echo e(url('question/create')); ?>" class="dark-blue-color side-nav-item">Add Question</a>
            <hr>

            <!-- SIDEBAR ITEM  -->
            <a href="<?php echo e(url('client')); ?>" class="dark-blue-color side-nav-item">View Client</a>
            <hr>

            <!-- SIDEBAR ITEM  -->
            <a href="<?php echo e(url('question')); ?>" class="dark-blue-color side-nav-item">View Questions</a>
            <hr>

            <!-- SIDEBAR ITEM  -->
            <a href="<?php echo e(url('question')); ?>" class="dark-blue-color side-nav-item">Dashboard</a>
            <hr>

            <!-- SIDEBAR ITEM  -->
            <a href="<?php echo e(url('result')); ?>" class="dark-blue-color side-nav-item pb-4">Results</a>

            <!-- SIDEBAR ITEM  -->
            <a href="<?php echo e(url('logout')); ?>" class="white-color logout-item red-background py-4">Log Out</a>
            
        </div>

     <!--************ SIDEBAR END ******************** --><?php /**PATH F:\xamp\htdocs\laravel\uncatadmin\resources\views/admin/include/siderbar.blade.php ENDPATH**/ ?>