<a href="#top" id="back-to-top">
	<svg class="svg-icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"/></svg>
</a>

<!-- Bootstrap4 js-->
<script src="<?php echo e(URL::asset('admin_assets/plugins/bootstrap/popper.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!--Othercharts js-->
<script src="<?php echo e(URL::asset('admin_assets/plugins/othercharts/jquery.sparkline.min.js')); ?>"></script>
<!-- Circle-progress js-->
<script src="<?php echo e(URL::asset('admin_assets/js/vendors/circle-progress.min.js')); ?>"></script>
<!-- Jquery-rating js-->
<script src="<?php echo e(URL::asset('admin_assets/plugins/rating/jquery.rating-stars.js')); ?>"></script>
<!--Sidemenu js-->
<script src="<?php echo e(URL::asset('admin_assets/plugins/sidemenu/sidemenu.js')); ?>"></script>
<!-- Clipboard js -->
<script src="<?php echo e(URL::asset('admin_assets/plugins/clipboard/clipboard.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/clipboard/clipboard.js')); ?>"></script>
<!-- Prism js -->
<script src="<?php echo e(URL::asset('admin_assets/plugins/prism/prism.js')); ?>"></script>
<!-- P-scroll js-->
<script src="<?php echo e(URL::asset('admin_assets/plugins/p-scrollbar/p-scrollbar.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/p-scrollbar/p-scroll1.js')); ?>"></script>
<!--Moment js-->
<script src="<?php echo e(URL::asset('admin_assets/plugins/moment/moment.js')); ?>"></script>
<!-- Daterangepicker js-->
<script src="<?php echo e(URL::asset('admin_assets/plugins/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/daterange.js')); ?>"></script>
<!--Chart js -->
<script src="<?php echo e(URL::asset('admin_assets/plugins/chart/chart.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/plugins/chart/chart.extension.js')); ?>"></script>
<!-- ECharts js-->
<script src="<?php echo e(URL::asset('admin_assets/plugins/echarts/echarts.js')); ?>"></script>
<!--Newsticker js-->
<script src="<?php echo e(URL::asset('admin_assets/plugins/newsticker/newsticker.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/newsticker.js')); ?>"></script>
<!--Select2 js -->
<script src="<?php echo e(URL::asset('admin_assets/plugins/select2/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/select2.js')); ?>"></script>
<!-- Index js-->
<script src="<?php echo e(URL::asset('admin_assets/js/index5.js')); ?>"></script>
<!-- Custom js-->
<script src="<?php echo e(URL::asset('admin_assets/js/custom.js')); ?>"></script>

<!-- Switcher js -->
<script src="<?php echo e(URL::asset('admin_assets/switcher/js/switcher.js')); ?>"></script>
	
	</body>
</html><?php /**PATH F:\xamp\htdocs\laravel\theallsafe\resources\views/admin/include/footer.blade.php ENDPATH**/ ?>