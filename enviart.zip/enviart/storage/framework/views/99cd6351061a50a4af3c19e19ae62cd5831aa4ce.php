<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UnCAT - Assessment Tool</title>

    <link rel="shortcut icon" href="media/logo.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
                  integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x"
                  crossorigin="anonymous">
    <!-- <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <link rel="stylesheet" href="css/animate.css"> -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css"> -->
    <!-- <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('admin_assets/css/style.css')); ?>">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap"
                  rel="stylesheet">
    <script src="https://kit.fontawesome.com/60a5beb53e.js" crossorigin="anonymous"></script>
</head>

<body>

    <!--************ NAVBAR ******************** -->

    <nav class="navbar navbar-expand-md navbar-light" id="header">
        <div class="container nav-container">
            <!-- NAVBAR BRAND  -->
            <a class="navbar-brand pl-2 pl-md-0" href="index.html">
                <img src="<?php echo e(URL::asset('admin_assets/media/uncat_logo.png')); ?>" alt="" class="logo-img img-responsive">
            </a>

            <!-- NAVBAR LINKS  -->
            <div class=" justify-content-end">
                <ul class="navbar-nav nav ml-auto black-clr">
                    <!-- NAV ITEM  -->
                    <li class="nav-item px-2 px-lg-3">
                        <a class="nav-link button white-color orange-background px-4 px-sm-5 f-semi-bold py-1"
                                      href="<?php echo e(url('clientlogin')); ?>">Login <span class="sr-only">(current)</span></a>
                    </li>
                </ul>

            </div>
        </div>
    </nav>
    <!--************ NAVBAR END ******************** -->


    <!--************ HOME BANNER ******************** -->
    
    <div class="banner-outer">
        <div class="banner container my-5 my-xl-0 d-flex align-items-center">
            <div class="row banner-row vw-100">
                <!-- HEADING COLUMN  -->
                <div
                              class="col-md-6 banner-col dark-blue-color d-flex align-items-center text-center text-md-start order-2 order-md-1">
                    <div class="banner-col-inner">
                        <!-- 1ST HEADING  -->
                        <div
                                      class="banner-heading1 d-flex align-items-center justify-content-center justify-content-md-start">
                            <h1 class="f-xbold m-0">
                                UnCAT - Assessment Tool
                            </h1>
                            <!-- <img src="media/substract.png" alt="" class="heading-hyphen ms-3 img-luid"> -->
                        </div>
                        <!-- <div class="banner-sub-heading">
                            <h5 class="f-semi-bold">
                                Unconscious Conditioning Assessment Tool
                            </h5>
                        </div> -->
                        <!-- 2ND HEADING  -->
                        <div class="banner-heading2 mt-4 mb-4 mb-md-5">
                            <h2 class="f-bold">
                                <!-- <span class="orange-underline">GET TO</span> KNOW <br class="d-none d-lg-block"> YOUR
                                EMPLOYER <br class="d-none d-lg-block"> BETTER -->
                                Understand your Mindset
                            </h2>
                        </div>
                        <!-- BANNER BUTTON  -->
                        <div class="banner-btn-div">
                            <a href="#" class="button banner-btn orange-background white-color f-semi-bold ">
                                Let's Start
                            </a>
                        </div>
                    </div>
                </div>
                <!-- IMAGE COLUMN  -->
                <div class="col-md-6 banner-col order-1 order-md-2 mb-3 mb-md-0 d-xl-none">
                    <img src="media/banner.png" alt="" class="banner-img img-fluid">
                </div>
            </div>
        </div>
    </div>
    


    <!--************ HOME BANNER END ******************** -->

    <!--************ WORKING DETAILS ******************** -->

    <div class="working-details container my-5">
        <!-- WORKING DETAILS HEADING -->
        <div class="section-heading working-details-main-heading dark-blue-color mb-3 text-center text-md-start">
            <h1 class="f-bold">
                What happens next?
            </h1>
        </div>

        <!-- WORKING DETAILS CARDS  -->

        <div class="row working-details-row dark-blue-color my-5">

            <!-- WORKING DETAILS COLUMN 1 -->
            <div class="col-md-4 working-details-col my-3 d-flex justify-content-center">
                <div class="working-details-col-inner p-5">
                    <!-- WORKING-DETAILS IMAGE  -->
                    <div class="working-details-icon d-flex justify-content-center">
                        <img src="media/work-deet1.png" alt="" class="working-details-img img-fluid">
                    </div>
                    <!-- WORKING DETAILS TEXT  -->
                    <div class="working-details-text f-semi-bold my-3">
                        <p>Get an email <br>from us</p>
                    </div>
                </div>
            </div>

            <!-- WORKING DETAILS COLUMN 2 -->
            <div class="col-md-4 working-details-col my-3 d-flex justify-content-center">
                <div class="working-details-col-inner p-5">
                    <!-- WORKING-DETAILS IMAGE  -->
                    <div class="working-details-icon d-flex justify-content-center">
                        <img src="media/work-deet2.png" alt="" class="working-details-img img-fluid">
                    </div>
                    <!-- WORKING DETAILS TEXT  -->
                    <div class="working-details-text f-semi-bold my-3">
                        <p>Complete the <br>assessment</p>
                    </div>
                </div>
            </div>

            <!-- WORKING DETAILS COLUMN 3 -->
            <div class="col-md-4 working-details-col my-3 d-flex justify-content-center">
                <div class="working-details-col-inner p-5">
                    <!-- WORKING-DETAILS IMAGE  -->
                    <div class="working-details-icon d-flex justify-content-center">
                        <img src="media/work-deet3.png" alt="" class="working-details-img img-fluid">
                    </div>
                    <!-- WORKING DETAILS TEXT  -->
                    <div class="working-details-text f-semi-bold my-3">
                        <p>Get a detailed <br>UnCAT report</p>
                    </div>
                </div>
            </div>


        </div>

    </div>


    <!--************ WORKING DETAILS END ******************** -->

    <!--************ NUMBERS ******************** -->

    <div class="numbers my-5 dark-blue-background">

        <div class="container numbers-container py-5 ">
            <div class="row numbers-row text-center white-color">

                <!-- NUMBER COLUMN  -->
                <div class="col-md-4 numbers-col my-2 d-flex d-lg-block justify-content-around align-items-center">

                    <!-- NUMBER CONTENT -->
                    <div class="numbers-content">
                        <span class="count white-color">23000</span>+
                        <br>
                        <p class="orange-color">Registered Users</p>
                    </div>
                </div>

                <!-- NUMBER COLUMN  -->
                <div class="col-md-4 numbers-col my-2 d-flex d-lg-block justify-content-around align-items-center">

                    <!-- NUMBER CONTENT  -->
                    <div class="numbers-content">
                        <span class="count white-color">13000</span>+
                        <br>
                        <p class="orange-color">Assessments Taken</p>
                    </div>
                </div>

                <!-- NUMBER COLUMN  -->
                <div class="col-md-4 numbers-col my-2 d-flex d-lg-block justify-content-around align-items-center">

                    <!-- NUMBER CONTENT  -->
                    <div class="numbers-content">
                        <span class="count white-color">1000</span>+
                        <br>
                        <p class="orange-color">Reports Generated</p>
                    </div>
                </div>
            </div>
        </div>


    </div>

    <!--************ NUMBERS END ******************** -->


    <!--************ END GOAL ******************** -->

    <div class="container end-goal my-5">
        <div class="row end-goal-row">
            <div class="col-md-6 end-goal-col my-3 d-flex justify-content-center align-items-center">
                <div class="end-goal-content">
                    <!-- END GOAL HEADING 1  -->
                    <div
                                  class="small-heading light-blue-color mb-3 d-flex align-items-center justify-content-center justify-content-md-start">
                        <img src="media/substract.png" alt="" class="heading-hyphen me-3 img-luid">
                        <h4 class="f-normal m-0">
                            End Goal
                        </h4>
                    </div>

                    <!-- END GOAL HEADING 2 -->
                    <div class="section-heading end-goal-heading mb-3 text-center text-md-start">
                        <h1 class="f-bold">
                            Get your Quality Report through UnCAT Assessment
                        </h1>
                    </div>


                </div>
            </div>
            <div class="col-md-6 end-goal-col my-3 d-flex justify-content-center align-items-center">
                <!-- END GOAL IMAGE  -->
                <div class="end-goal-img-outer ">
                    <img src="media/report.png" alt="" class="end-goal-img img-fluid">
                </div>
            </div>
        </div>
    </div>



    <!--************ END GOAL END ******************** -->

    <!--************ FOOTER ******************** -->

    <footer class="footer dark-blue-background">
        <div class="container footer-container py-5">
            <div class="row footer-row white-color position-relative">
                <!-- FOOTER COLUMN 1  -->
                <div class="col-md-6 footer-col my-3">
                    <!-- FOOTER COLUMN HEADING  -->
                    <div class="footer-col-heading">
                        <p>Contact Us:</p>
                    </div>
                    <!-- FOOTER COLUMN TEXT  -->
                    <div class="footer-col-text">
                        <a href="mailto:uncatserver@gmail.com" class="white-color">uncatserver@gmail.com</a>
                    </div>
                </div>

                <!-- FOOTER COLUMN 2 -->
                <div class="col-md-6 footer-col my-3 text-md-end">
                    <!-- FOOTER COLUMN HEADING  -->
                    <div class="footer-col-heading">
                        <p>Reach us at Tandemhive Global</p>
                    </div>
                    
                </div>

                <div class="footer-copyright mt-3 col-12">
                    <div class="copyright-content d-flex align-items-center justify-content-center">
                        <div class="copyright-text">
                            <p class="white-color m-0">Powered by - </p>
                        </div>
                        <div class="copyright-image-outer">
                            <img src="media/christ.png" alt="" class="copyright-img img-fluid ms-2">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>



    <!--************ FOOTER END ******************** -->




    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
                  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
                  integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
                  crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"
                  integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT"
                  crossorigin="anonymous"></script>
    <!-- <script src="js/wow.min.js"></script>
    <script src="js/owl.carousel.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script> -->
    <!-- <script data-cfasync="false" type="text/javascript" src="js/form-submission-handler.min.js" defer></script> -->
    <script type="text/javascript" src="<?php echo e(URL::asset('admin_assets/js/script.js')); ?>"></script>
</body>

</html><?php /**PATH /home/bittaskc/public_html/uncat/uncatadmin/resources/views/landing.blade.php ENDPATH**/ ?>