		<!-- Meta data -->
		<meta charset="UTF-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
		<meta content="Dashtic - Bootstrap Webapp Responsive Dashboard Simple Admin Panel Premium HTML5 Template" name="description">
		<meta content="Spruko Technologies Private Limited" name="author">
		<meta name="keywords" content="Admin, Admin Template, Dashboard, Responsive, Admin Dashboard, Bootstrap, Bootstrap 4, Clean, Backend, Jquery, Modern, Web App, Admin Panel, Ui, Premium Admin Templates, Flat, Admin Theme, Ui Kit, Bootstrap Admin, Responsive Admin, Application, Template, Admin Themes, Dashboard Template"/>
		<!-- Title -->
<title>The All Safe</title>
<!--Favicon -->
<link rel="icon" href="<?php echo e(URL::asset('admin_assets/images/brand/favicon.ico')); ?>" type="image/x-icon"/>
<!-- Bootstrap css -->
<link href="<?php echo e(URL::asset('admin_assets/plugins/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet" />
<!-- Style css -->
<link href="<?php echo e(URL::asset('admin_assets/css/style.css')); ?>" rel="stylesheet" />
<!-- Dark css -->
<link href="<?php echo e(URL::asset('admin_assets/css/dark.css')); ?>" rel="stylesheet" />
<!-- Skins css -->
<link href="<?php echo e(URL::asset('admin_assets/css/skins.css')); ?>" rel="stylesheet" />
<!-- Animate css -->
<link href="<?php echo e(URL::asset('admin_assets/css/animated.css')); ?>" rel="stylesheet" />
<!--Sidemenu css -->
<link id="theme" href="<?php echo e(URL::asset('admin_assets/css/sidemenu.css')); ?>" rel="stylesheet">
<!-- P-scroll bar css-->
<link href="<?php echo e(URL::asset('admin_assets/plugins/p-scrollbar/p-scrollbar.css')); ?>" rel="stylesheet" />
<!-- Prism Css -->
<link href="<?php echo e(URL::asset('admin_assets/plugins/prism/prism.css')); ?>" rel="stylesheet">
<!---Icons css-->
<link href="<?php echo e(URL::asset('admin_assets/plugins/web-fonts/icons.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('admin_assets/plugins/web-fonts/font-awesome/font-awesome.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('admin_assets/plugins/web-fonts/plugin.css')); ?>" rel="stylesheet" />

<!-- Switcher css -->
<link href="<?php echo e(URL::asset('admin_assets/switcher/css/switcher.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('admin_assets/switcher/demo.css')); ?>" rel="stylesheet">

<!-- News-Ticker css-->
<link href="<?php echo e(URL::asset('admin_assets/plugins/newsticker/newsticker.css')); ?>" rel="stylesheet" />
<!-- Select2 css -->
<link href="<?php echo e(URL::asset('admin_assets/plugins/select2/select2.min.css')); ?>" rel="stylesheet" />
<!--Daterangepicker css-->
<link href="<?php echo e(URL::asset('admin_assets/plugins/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" />
<?php /**PATH F:\xamp\htdocs\laravel\theallsafe\resources\views/admin/include/head.blade.php ENDPATH**/ ?>