<!DOCTYPE html>
<html lang="ar" <?php if(session('type')==0): ?> dir="rtl"  <?php endif; ?>>

<head>
    <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(URL::asset('public/assets/img/apple-icon.png')); ?>') }}">
  <link rel="icon" type="image/png" href="<?php echo e(URL::asset('public/assets/img/favicon.png')); ?>">
  <title>
    Admin
  </title>
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="<?php echo e(URL::asset('public/assets/css/nucleo-icons.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(URL::asset('public/assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <link href="<?php echo e(URL::asset('public/assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
  <!-- CSS Files -->
  <link id="pagestyle" href="<?php echo e(URL::asset('public/assets/css/soft-ui-dashboard.css?v=1.0.4')); ?>" rel="stylesheet" />
</head>

<body class="g-sidenav-show  bg-gray-100  <?php if(session('type')==0): ?> rtl  <?php endif; ?>">
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <!-- Navbar -->
<?php 
if(session('type')==0)
{     
    $td0="ID";
    $td1="Invoice number";
    $td2="Invoice date";
    $td3="Customer name";
    $td4="Invoice amount";
    $td5="VAT amount";
}
else  
{
    $td0="ID";
    $td1="Invoice number";
    $td2="Invoice date";
    $td3="Customer name";
    $td4="Invoice amount";
    $td5="VAT amount";
    $td6=0;
    $td7=0;
}
?>
<div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card">
			    <!-- Card header -->
            <div class="card-body px-0 pb-0">
              <div class="table-responsive">
                <table class="table table-flush" id="products-list">
                  <thead class="thead-light">
                    <tr>
                      <th><?php echo e($td1); ?></th>
                      <th><?php echo e($td2); ?></th>
                      <th><?php echo e($td3); ?></th>
                      <th><?php echo e($td4); ?></th>
                      <th><?php echo e($td5); ?></th>
                    </tr>
                  </thead>
                  <tbody><?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                        <div class="d-flex">
                        <h6 class="my-auto"><?php echo e($value->id); ?></h6>
                        </div>
                        </td>
                        <td>
                        <div class="d-flex">
                        <h6 class="my-auto"><?php echo e($value->created_at); ?></h6>
                        </div>
                        </td>
                        <td>
                        <div class="d-flex">
                        <h6 class="my-auto"><?php echo e($value->customer_name); ?></h6>
                        </div><?php $td6=$td6+$value->order_total_amount_due; $td7=$td7+$value->order_tax_per; ?>
                        </td>
                        <td class="text-sm"><?php echo e($value->order_total_amount_due); ?></td>
                        <td class="text-sm"><?php echo e($value->order_tax_per); ?></td>
                    </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  <tbody>
                    <tr>
                        <td class="text-sm"></td>
                        <td class="text-sm"></td>
                        <td class="text-sm"></td>
                        <td>
                        <div class="d-flex">
                        <h6 class="my-auto"><?php echo e($td6); ?></h6>
                        </div>
                        </td>
                        <td>
                        <div class="d-flex">
                        <h6 class="my-auto"><?php echo e($td7); ?></h6>
                        </div>
                        </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
 </main>
    <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

</body>

</html><?php /**PATH /home/blueczur/gulfbills.com/demo/resources/views/admin/mail.blade.php ENDPATH**/ ?>