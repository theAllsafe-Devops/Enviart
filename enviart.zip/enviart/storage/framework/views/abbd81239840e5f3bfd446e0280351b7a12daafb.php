<!DOCTYPE html>
<html lang="ar" <?php if(session('type')==0): ?> dir="rtl"  <?php endif; ?>>

<head>
    <?php echo $__env->make('admin.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="g-sidenav-show  bg-gray-100  <?php if(session('type')==0): ?> rtl  <?php endif; ?>">
    <?php echo $__env->make('admin.include.siderbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <!-- Navbar -->
     <?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('mainarea'); ?>
    <!-- End Navbar -->
  </main>
    <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

</body>

</html><?php /**PATH /home/blueczur/gulfbills.com/demo/resources/views/admin/include/layout.blade.php ENDPATH**/ ?>