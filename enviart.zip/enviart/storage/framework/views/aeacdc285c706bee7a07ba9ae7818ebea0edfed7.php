<?php echo e($slot); ?>

<?php /**PATH /home3/scsyin/public_html/callrecording/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>