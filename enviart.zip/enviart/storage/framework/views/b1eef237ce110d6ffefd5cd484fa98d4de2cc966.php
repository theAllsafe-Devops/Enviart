
<?php $__env->startSection('mainarea'); ?>
<script src="<?php echo e(URL::asset('public/assets/js/plugins/datatables.js')); ?>"></script>
<div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card">
              <?php if(session()->has('delete')): ?>
                    <div class="alert alert-success" role="alert">
                      <strong>Success!</strong> <?php echo e(session()->get('delete')); ?>

                  `</div>
            	<?php endif; ?>
            <!-- Card header -->
            <div class="card-header pb-0">
              <div class="d-lg-flex">
                <div class="ms-auto my-auto mt-lg-0 mt-4">
                  <h5 class="mb-0"> <?php if(session('type')==0): ?>  جميع المنتجات    <?php else: ?> All Products  <?php endif; ?></h5>
                  
                </div>
                <div class="ms-auto my-auto mt-lg-0 mt-4">
                  <div class="ms-auto my-auto">
                    <a href="<?php echo e(url('admin/product/create')); ?>" class="btn bg-gradient-info btn-sm mb-0">+&nbsp;  <?php if(session('type')==0): ?>  منتج جديد    <?php else: ?> New Product  <?php endif; ?></a>
                    <button class="btn btn-outline-info btn-sm export mb-0 mt-sm-0 mt-1" data-type="csv" type="button" name="button"> <?php if(session('type')==0): ?>  يصدر    <?php else: ?> Export  <?php endif; ?></button>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-body px-0 pb-0">
              <div class="table-responsive">
                <table class="table table-flush" id="products-list">
                  <thead class="thead-light">
                    <tr>
                      <th> <?php if(session('type')==0): ?>  هوية شخصية    <?php else: ?> ID <?php endif; ?></th>
                      <th> <?php if(session('type')==0): ?>  المنتج    <?php else: ?> Product <?php endif; ?></th>
                      <th> <?php if(session('type')==0): ?>  سعر    <?php else: ?> Price <?php endif; ?></th>
                      <!--<th> <?php if(session('type')==0): ?>  حالة    <?php else: ?> Status <?php endif; ?></th>-->
                      <th> <?php if(session('type')==0): ?>  عمل    <?php else: ?> Action  <?php endif; ?></th>
                    </tr>
                  </thead>
                  <tbody><?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?></td>
                      <td>
                        <div class="d-flex">
                          <h6 class="ms-3 my-auto"><?php echo e($value->product_name); ?></h6>
                        </div>
                      </td>
                      <td class="text-sm"><?php echo e($value->price); ?></td>
                      <!--<td>-->
                      <!--  <?php if($value->status==1): ?> <span class="badge badge-success  badge-sm">Active</span> <?php endif; ?>-->
                      <!--  <?php if($value->status==0): ?> <span class="badge badge-danger badge-sm">In Active</span> <?php endif; ?>-->
                      <!--</td>-->
                      <td class="text-sm">
                        <a href="<?php echo e(url('admin/product/edit')); ?>/<?php echo e($value->id); ?>" class="mx-3" data-bs-toggle="tooltip" data-bs-original-title="Edit product">
                          <i class="fas fa-user-edit text-secondary"></i>
                        </a>
                        <a href="<?php echo e(url('admin/product/destroy')); ?>/<?php echo e($value->id); ?>" onclick="return confirm('Are you sure you want to delete this item?');" data-bs-toggle="tooltip" data-bs-original-title="Delete product">
                          <i class="fas fa-trash text-secondary"></i>
                        </a>
                      </td>
                    </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
    if (document.getElementById('products-list')) {
      const dataTableSearch = new simpleDatatables.DataTable("#products-list", {
        searchable: true,
        fixedHeight: false,
        perPage: 7
      });

      document.querySelectorAll(".export").forEach(function(el) {
        el.addEventListener("click", function(e) {
          var type = el.dataset.type;

          var data = {
            type: type,
            filename: "soft-ui-" + type,
          };

          if (type === "csv") {
            data.columnDelimiter = "|";
          }

          dataTableSearch.export(data);
        });
      });
    };
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blueczur/gulfbills.com/mct/resources/views/admin/product/index.blade.php ENDPATH**/ ?>