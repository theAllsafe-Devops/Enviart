<html>
    <p>Your new password , : <?php echo e($password); ?></b></p>
</html><?php /**PATH /home3/scsyin/public_html/gym/resources/views/admin/forgetmail.blade.php ENDPATH**/ ?>