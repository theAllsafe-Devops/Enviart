
<?php $__env->startSection('mainarea'); ?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
	  <div class="container-full">
		<!-- Content Header (Page header) -->
		<div class="content-header">
			<div class="d-flex align-items-center">
				<div class="mr-auto">
					<h3 class="page-title">List</h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item" aria-current="page">List</li>
								<li class="breadcrumb-item active" aria-current="page">Session List</li>
							</ol>
						</nav>
					</div>
				</div>
				<div class="right-title">
				    <button data-toggle="modal" data-target="#modal-center" class="btn btn-outline btn-success mb-5">Add Session</button>
				</div>
			</div>
		</div>

		<!-- Main content -->
		<section class="content">
		  <div class="row">
			  
			<div class="col-12">
				<div class="box">
					<div class="box-header">						
						<h4 class="box-title">Session List</h4>
					</div>
					<?php if(session()->has('status')): ?>
            		<div class="alert alert-info">
            				<?php echo e(session()->get('status')); ?>

            			</div>
            		<?php endif; ?>
					<div class="box-body">
						<div class="table-responsive">
							<table id="example1" class="table table-striped table-bordered display" style="width:100%">
								<thead>
									<tr>
										<th>Id</th>
										<th>Session</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e(++$key); ?></td>
										<td><?php echo e($value->session); ?></td>
										<td><a class="btn btn-outline btn-success mb-5" href="<?php echo e(url('partner/session/edit')); ?>/<?php echo e($value->id); ?>"><i class="fa fa-edit"></i></a>
                    						<a class="btn btn-outline btn-success mb-5" href="<?php echo e(url('partner/session/destroy')); ?>/<?php echo e($value->id); ?>" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fa fa-trash-o"></i></a>
                    					</td>
									</tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
					</table>
					</div>              
				</div>
				<!-- /.box-body -->
			  </div>
			  <!-- /.box -->          
			</div>
			<!-- /.col -->
		  </div>
		  <!-- /.row -->
		</section>
		<!-- /.content -->
	  
	  </div>
  </div>
  <!-- /.content-wrapper -->
	<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/jquery-3.3.1/jquery-3.3.1.js')); ?>"></script>
	
	<!-- jQuery UI 1.11.4 -->
	<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/jquery-ui/jquery-ui.js')); ?>"></script>
	
	<!-- popper -->
	<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/popper/dist/popper.min.js')); ?>"></script>
<!-- Modal -->
  <div class="modal center-modal fade" id="modal-center" tabindex="-1">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title">Session</h5>
			<button type="button" class="close" data-dismiss="modal">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  <form novalidate action="<?php echo e(url('partner/session/store')); ?>" method="POST">
		  <div class="modal-body">
			<div class="box-body">
			    <?php echo csrf_field(); ?>
				<div class="form-group row">
					<label class="col-form-label col-md-2">session</label>
					<div class="col-md-10">
					    <div class="controls">
						<input class="form-control" type="text" name="session" required data-validation-required-message="This field is required">
					    </div>
					</div>
				</div>
			</div>
		  </div>
		  <div class="modal-footer modal-footer-uniform">
			<button type="button" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Close</button>
			<button type="submit" class="btn btn-bold btn-pure btn-primary float-right">Save</button>
		  </div>
		  </form>
		</div>
	  </div>
	</div>
  <!-- /.modal -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partner.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/scsyin/public_html/schoolbuddy/schoolbuddy/resources/views/partner/session/index.blade.php ENDPATH**/ ?>