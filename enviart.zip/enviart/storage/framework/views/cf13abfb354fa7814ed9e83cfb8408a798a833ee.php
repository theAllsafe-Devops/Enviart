
<?php $__env->startSection('content'); ?>

    <!--************ VIEW QUESTION ******************** -->

    <div class="container view-client my-5">
        <!-- VIEW QUESTION HEADING  -->
        <div class="section-heading instructions-main-heading dark-blue-color mb-3 text-center">
            <h1 class="f-bold">
                View Questions
            </h1>
        </div>

        <!-- VIEW-QUESTION CARDS  -->
        <div class="row view-client-row my-5">
            <!-- VIEW-QUESTION COLUMN 1  --><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4 view-client-col p-3">
                <div class="card address-card m-auto h-100">
                    <!-- VIEW-QUESTION CARD CONTENT  -->
                    <div class="card-body address-card-body">
                        <p class="client-card-head f-semi-bold dark-blue-color">
                            Question New Number: <br> <span
                                          class="client-card-text orange-color f-normal ms-2"><?php echo e($i->new_serial_number); ?></span>
                        </p>
                        <p class="client-card-head f-semi-bold dark-blue-color">
                            Question Old Number: <br> <span
                                          class="client-card-text orange-color f-normal ms-2"><?php echo e($i->old_serial_number); ?></span>
                        </p>
                        <p class="client-card-head f-semi-bold dark-blue-color">
                            Question: <br> <span class="client-card-text orange-color f-normal ms-2"><em><?php echo e($i->your_question); ?></em></span>
                        </p>
                        <p class="client-card-head f-semi-bold dark-blue-color">
                            Category: <br> <span class="client-card-text orange-color f-normal ms-2"><?php echo e($i->question_section); ?></span>
                        </p>
                        <p class="client-card-head f-semi-bold dark-blue-color">
                            Scoring Type: <br> <span class="client-card-text orange-color f-normal ms-2"> <?php if($i->score_type==1): ?> Direct Score <?php endif; ?> 
                            <?php if($i->score_type==2): ?> Reverse Score <?php endif; ?>
                            <?php if($i->score_type==3): ?> SDQ <?php endif; ?></span>
                        </p>

                    </div>
                    <!-- CLIENT EDIT LINKS  -->
                    <div class="client-edit-links d-flex align-baseline justify-content-between">
                        <div class="client-links-inner px-3 mb-3">
                            <a href=<?php echo e("question/edit/".$i->id); ?> class="edit-client px-1 black-color">Edit</a>
                        </div>
                        <div class="client-links-inner px-3 mb-3">
                            <a href=<?php echo e("question/destroy/".$i->id); ?> class="delete-client px-1">Delete</a>
                        </div>
                    </div>
                </div>
            </div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

        </div>



    </div>



    <!--************ VIEW CLIENT END ******************** -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bittaskc/public_html/uncat/uncatadmin/resources/views/admin/question/index.blade.php ENDPATH**/ ?>