
<?php $__env->startSection('content'); ?>

    <!--************ ADD-CLIENT ******************** -->

    <div class="container add-client my-5">
        <!-- ADD-CLIENT HEADING  -->
        <div class="section-heading instructions-main-heading dark-blue-color mb-3 text-center">
            <h1 class="f-bold">
                Add Client
            </h1>
        </div>
        <?php if(session()->has('status')): ?>
		<div class="alert alert-info">
				<?php echo e(session()->get('status')); ?>

			</div>
		<?php endif; ?>
		<?php if($errors->has('name')): ?>
            <span class="text-danger"><?php echo e($errors->first('name')); ?></span><br>
        <?php endif; ?>
        
        <?php if($errors->has('email')): ?>
            <span class="text-danger"><?php echo e($errors->first('email')); ?></span><br>
        <?php endif; ?>
        <?php if($errors->has('phone')): ?>
            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span><br>
        <?php endif; ?>
        <?php if($errors->has('password')): ?>
            <span class="text-danger"><?php echo e($errors->first('password')); ?></span><br>
        <?php endif; ?>
        <?php if($errors->has('age')): ?>
            <span class="text-danger"><?php echo e($errors->first('age')); ?></span><br>
        <?php endif; ?>
        <?php if($errors->has('qualification')): ?>
            <span class="text-danger"><?php echo e($errors->first('qualification')); ?></span><br>
        <?php endif; ?>
        <?php if($errors->has('years_of_experience')): ?>
            <span class="text-danger"><?php echo e($errors->first('years_of_experience')); ?></span><br>
        <?php endif; ?>
        <form class="add-client-form my-5" action="<?php echo e(url('client/store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="d-block d-md-flex justify-content-between align-items-center">
                <div class="form-group my-3 w-100">
                    <input type="text" class="form-control login-signup-input add-client-input py-3 orange-color m-auto"
                                  id="" aria-describedby="" placeholder="Name" required name="name">
                </div>
                
                <div class="form-group my-3 w-100">
                    <input type="email"
                                  class="form-control login-signup-input add-client-input py-3 orange-color m-auto"
                                  id="" placeholder="Email" name="email">
                
                </div>
                
            </div>
            
            <div class="d-block d-md-flex justify-content-between align-items-center">
                <div class="form-group my-3 w-100">
                    <input type="text" class="form-control login-signup-input add-client-input py-3 orange-color m-auto"
                                  id="" aria-describedby="" placeholder="Phone" required name="phone">
                </div>
                
                <div class="form-group my-3 w-100">
                    <input type="password"
                                  class="form-control login-signup-input add-client-input py-3 orange-color m-auto"
                                  id="" placeholder="Password" required name="password">
                </div>
                
            </div>
            <div class="d-block d-md-flex justify-content-between align-items-center">
                <div class="form-group my-3 w-100">
                    <input type="text"
                                  class="form-control login-signup-input add-client-input py-3 orange-color m-auto"
                                  id="" aria-describedby="" placeholder="Age" required name="age">
                </div>
                
                <div class="form-group my-3 w-100">
                    <input type="text" class="form-control login-signup-input add-client-input py-3 orange-color m-auto"
                                  id="" placeholder="Qualification" required name="qualification">
                </div>
                
            </div>
            <div class="d-block d-md-flex justify-content-between align-items-center">
                <div class=" my-3 w-100">
                    <select class="form-select login-signup-input add-client-input py-3 dark-blue-color m-auto" aria-label="Default select example" name="gender">
                        <option selected>Gender</option>
                        <option value="1">Male</option>
                        <option value="2">Others</option>
                        <option value="3">Female</option>
                      </select>
                </div>
                
                <div class="form-group my-3 w-100">
                    <input type="text"
                                  class="form-control login-signup-input add-client-input py-3 orange-color m-auto"
                                  id="" placeholder="Years of Experience" required name="years_of_experience">
                </div>
                
            </div>
            <div class="d-block d-md-flex justify-content-between align-items-center">
                <div class="form-group my-3 w-100">
                    <input type="date" class="form-control login-signup-input add-client-input dark-blue-color py-3  m-auto" id=""
                                  aria-describedby="" placeholder="Starting Date" required name="starting_Date">
                </div>
                <div class="form-group my-3 w-100">
                    <input type="date" class="form-control login-signup-input add-client-input dark-blue-color py-3  m-auto" id=""
                                  placeholder="Closing Date" required name="closing_Date">
                </div>
            </div>

            <div class="submit-btn-outer text-center my-5">
                <button type="submit" class="button f-semi-bold dark-blue-background white-color login-signup-btn add-client-btn py-3">Add</button>
            </div>
        </form>
    </div>
    	<div class="container">
    <div class="card bg-light mt-3">
        <div class="card-header">
            Import Export Example
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="file" name="file" class="form-control">
                <br>
                <button class="btn btn-success">Import Bulk Data</button>
            </form>
        </div>
    </div>
</div>


    <!--************ ADD-CLIENT END ******************** -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\laravel\uncatadmin\resources\views/admin/client/create.blade.php ENDPATH**/ ?>