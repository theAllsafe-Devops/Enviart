
<!DOCTYPE html>
<html lang="en" dir="ltr">
	
<!-- Mirrored from laravel.spruko.com/dashtic/Leftmenu-Icon-LightSidebar-ltr/login-2 by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 31 Aug 2020 13:22:26 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
		<!-- Meta data -->
		<meta charset="UTF-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
		<meta content="Dashtic - Bootstrap Webapp Responsive Dashboard Simple Admin Panel Premium HTML5 Template" name="description">
		<meta content="Spruko Technologies Private Limited" name="author">
		<meta name="keywords" content="Admin, Admin Template, Dashboard, Responsive, Admin Dashboard, Bootstrap, Bootstrap 4, Clean, Backend, Jquery, Modern, Web App, Admin Panel, Ui, Premium Admin Templates, Flat, Admin Theme, Ui Kit, Bootstrap Admin, Responsive Admin, Application, Template, Admin Themes, Dashboard Template"/>
		<!-- Title -->
<title>The all safe</title>
<!--Favicon -->
<link rel="icon" href="<?php echo e(URL::asset('admin_assets/images/brand/favicon.ico')); ?>" type="image/x-icon"/>
<!-- Bootstrap css -->
<link href="<?php echo e(URL::asset('admin_assets/plugins/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet" />
<!-- Style css -->
<link href="<?php echo e(URL::asset('admin_assets/css/style.css')); ?>" rel="stylesheet" />
<!-- Dark css -->
<link href="<?php echo e(URL::asset('admin_assets/css/dark.css')); ?>" rel="stylesheet" />
<!-- Skins css -->
<link href="<?php echo e(URL::asset('admin_assets/css/skins.css')); ?>" rel="stylesheet" />
<!-- Animate css -->
<link href="<?php echo e(URL::asset('admin_assets/css/animated.css')); ?>" rel="stylesheet" />
<!---Icons css-->
<link href="<?php echo e(URL::asset('admin_assets/plugins/web-fonts/icons.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('admin_assets/plugins/web-fonts/font-awesome/font-awesome.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('admin_assets/plugins/web-fonts/plugin.css')); ?>" rel="stylesheet" />
	</head>
		
	<body class="h-100vh page-style1 light-mode default-sidebar">	    
				<div class="d-md-flex">
			<div class="w-40 bg-style h-100vh page-style">
				<div class="page-content">
					<div class="page-single-content">
						<img src="<?php echo e(URL::asset('admin_assets/images/brand/theAllsafe_Blue_All.png')); ?>" alt="img" class="header-brand-img mb-5">
						<div class="card-body text-white py-5 px-8 text-center">
							<img src="<?php echo e(URL::asset('admin_assets/images/png/3.png')); ?>" alt="img" class="w-100 mx-auto text-center">
						</div>
					</div>
				</div>
			</div>
			<div class="w-80 page-content">
				<div class="page-single-content">
					<div class="card-body p-6">
						<div class="row">
							<div class="col-md-8 mx-auto d-block">
								<div class="">
									<h1 class="mb-2">Login</h1>
									<p class="text-muted">Sign In to your account</p>
								</div>
								<?php if(session()->has('error')): ?>
								<div class="alert alert-danger">
										<?php echo e(session()->get('error')); ?>

									</div>
								<?php endif; ?>
								<form action="<?php echo e(url('makelogin')); ?>" method="POST">
								<?php echo csrf_field(); ?>
									<div class="input-group mb-3">
										<span class="input-group-addon"><svg class="svg-icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M12 16c-2.69 0-5.77 1.28-6 2h12c-.2-.71-3.3-2-6-2z" opacity=".3"/><circle cx="12" cy="8" opacity=".3" r="2"/><path d="M12 14c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4zm-6 4c.22-.72 3.31-2 6-2 2.7 0 5.8 1.29 6 2H6zm6-6c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0-6c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2z"/></svg></span>
										<input type="text" class="form-control" name="email" placeholder="Username">
									</div>
									<div class="input-group mb-4">
										<span class="input-group-addon"><svg class="svg-icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><g fill="none"><path d="M0 0h24v24H0V0z"/><path d="M0 0h24v24H0V0z" opacity=".87"/></g><path d="M6 20h12V10H6v10zm6-7c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2z" opacity=".3"/><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM9 6c0-1.66 1.34-3 3-3s3 1.34 3 3v2H9V6zm9 14H6V10h12v10zm-6-3c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2z"/></svg></span>
										<input type="password" class="form-control" name="password" placeholder="Password">
									</div>
									<div class="row">
										<div class="col-12">
											<a href="forgot-password-1.html" class="btn btn-link box-shadow-0 px-0">Forgot password?</a>
										</div>
										<div class="col-12">
											<button type="submit" class="btn btn-primary btn-block"> <i class="fe fe-arrow-right"></i> Login</button>
										</div>
									</div>
								<form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Jquery js-->
<script src="{{ URL::asset('admin_assets/js/vendors/jquery-3.5.1.min.js"></script>
<!-- Bootstrap4 js-->
<script src="{{ URL::asset('admin_assets/plugins/bootstrap/popper.min.js"></script>
<script src="{{ URL::asset('admin_assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!--Othercharts js-->
<script src="{{ URL::asset('admin_assets/plugins/othercharts/jquery.sparkline.min.js"></script>
<!-- Circle-progress js-->
<script src="{{ URL::asset('admin_assets/js/vendors/circle-progress.min.js"></script>
<!-- Jquery-rating js-->
<script src="{{ URL::asset('admin_assets/plugins/rating/jquery.rating-stars.js"></script>
	
	</body>

<!-- Mirrored from laravel.spruko.com/dashtic/Leftmenu-Icon-LightSidebar-ltr/login-2 by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 31 Aug 2020 13:22:56 GMT -->
</html><?php /**PATH F:\xamp\htdocs\laravel\theallsafe\resources\views/admin/login.blade.php ENDPATH**/ ?>