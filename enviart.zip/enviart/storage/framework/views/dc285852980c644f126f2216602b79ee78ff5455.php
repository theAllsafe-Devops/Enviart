
<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<script src="<?php echo e(URL::asset('admin_assets/plugins/fileupload/js/dropify.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin_assets/js/filupload.js')); ?>"></script>
<link href="<?php echo e(URL::asset('admin_assets/plugins/fileupload/css/fileupload.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(URL::asset('admin_assets/plugins/fileupload/css/fileupload.css')); ?>" rel="stylesheet" type="text/css">
				<div class="app-content main-content">
					<div class="side-app">
						<!--app header-->
                        <?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<!--/app header-->
												<!--Page header-->
						<div class="page-header">
							<div class="page-leftheader">
								<h4 class="page-title">Crypto Dashboard</h4>
                                <?php if(session()->has('status')): ?>
								<div class="alert alert-danger">
										<?php echo e(session()->get('status')); ?>

									</div>
								<?php endif; ?>
							</div>
							<div class="page-rightheader ml-auto d-lg-flex d-none">
								<div class="ml-5 mb-0">
                                <a href="<?php echo e(URL::asset('category/create')); ?>" class="btn btn-primary"><i class="fe fe-plus mr-2"></i>Add Category</a>
								</div>
							</div>
						</div>
						<!--End Page header-->
						<!--Row-->
                        <div class="row">
							<div class="col-12">
                                <div class="card">
									<div class="card-header">
										<h3 class="card-title">Inputs &amp; Textareas </h3>
									</div>
									<div class="card-body pb-2">
                                        <form action="<?php echo e(url('category/store')); ?>" method="POST" enctype="multipart/form-data">
										<div class="row row-sm">
								            <?php echo csrf_field(); ?>
											<div class="col-lg">
                                                <div class="dropify-wrapper" style="height: 191.985px;"><div class="dropify-message"><span class="file-icon"> <p>Drag and drop a file here or click</p></span><p class="dropify-error">Ooops, something wrong appended.</p></div><div class="dropify-loader"></div><div class="dropify-errors-container"><ul></ul></div>
                                                <input type="file" name="image" class="dropify" data-height="180"><button type="button" class="dropify-clear mb-4">Remove</button><div class="dropify-preview"><span class="dropify-render"></span><div class="dropify-infos"><div class="dropify-infos-inner"><p class="dropify-filename"><span class="dropify-filename-inner"></span></p><p class="dropify-infos-message">Drag and drop or click to replace</p></div></div></div></div>
											</div>
											<div class="col-lg mg-t-10 mg-lg-t-0">
												<input class="form-control mb-8" name="Category_name" placeholder="Category Name" type="text">
                                                <input class="btn btn-primary mb-8" type="submit">
											</div>
                                        
										</div></form>
									</div>
								</div>
								<!--/div-->
							</div>
						</div>
						<!--End Row-->

					</div>
				</div><!-- end app-content-->

<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\laravel\theallsafe\resources\views/admin/category/create.blade.php ENDPATH**/ ?>