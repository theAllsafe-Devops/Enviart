
<?php $__env->startSection('content'); ?>
    <div class="container admin-dashboard-client my-5">
        <!-- ADMIN DASHBOARDHEADING  -->
        <div class="section-heading instructions-main-heading dark-blue-color mb-3 text-center">
            <h1 class="f-bold">
                Welcome Admin
            </h1>
        </div>

        <!-- ADMIN DASHBOARD CARDS  -->
        <div class="row admin-dashboard-row white-color m-auto my-5">

            <!-- ADMIN DASHBOARD COLUMN 1 -->
            <div class="col-sm-6 col-md-4 p-3 my-3 col-xl-3 admin-dashboard-col d-flex justify-content-center align-items-center"><a href="<?php echo e(url('client/create')); ?>">
                <div class="admin-dashboard-col-inner h-100 w-100 orange-background p-4">
                    <!-- ADMIN DASHBOARD IMAGE  -->
                    <div class="working-details-icon d-flex justify-content-center " style="color: white;text-align: center;">
                        <i class="fas fa-user-plus admin-dashboard-image"></i>
                    </div>
                    <!-- ADMIN DASHBOARD TEXT  -->
                    
                        <div class="admin-dashboard-text f-normal mt-5 text-center">
                            <p class="m-0">ADD USER</p>
                        </div>
                    
                </div></a>
            </div>

            <!-- ADMIN DASHBOARD COLUMN 2 -->
            <div class="col-sm-6 col-md-4 p-3 my-3 col-xl-3 admin-dashboard-col d-flex justify-content-center align-items-center"><a href="<?php echo e(url('question/create')); ?>">
                <div class="admin-dashboard-col-inner h-100 w-100 orange-background p-4">
                    <!-- ADMIN DASHBOARD IMAGE  -->
                    <div class="working-details-icon d-flex justify-content-center " style="color: white;">
                        <i class="far fa-clipboard admin-dashboard-image"></i>
                    </div>
                    <!-- ADMIN DASHBOARD TEXT  -->
                    
                    <div class="admin-dashboard-text f-normal mt-5 text-center">
                        <p class="m-0">ADD QUESTION</p>
                    </div>
                   
                </div></a>
            </div> 

            <!-- ADMIN DASHBOARD COLUMN 3 -->
            <div class="col-sm-6 col-md-4 p-3 my-3 col-xl-3 admin-dashboard-col d-flex justify-content-center align-items-center"><a href="<?php echo e(url('question')); ?>">
                <div class="admin-dashboard-col-inner h-100 w-100  orange-background p-4">
                    <!-- ADMIN DASHBOARD IMAGE  -->
                    <div class="working-details-icon d-flex justify-content-center " style="color: white;">
                        <i class="fas fa-clipboard admin-dashboard-image"></i>
                    </div>
                    <!-- ADMIN DASHBOARD TEXT  -->
                    
                    <div class="admin-dashboard-text f-normal mt-5 text-center">
                        <p class="m-0">VIEW QUESTION</p>
                    </div>
                    
                </div></a>
            </div>

            <!-- ADMIN DASHBOARD COLUMN 4 -->
            <div class="col-sm-6 col-md-4 p-3 my-3 col-xl-3 admin-dashboard-col d-flex justify-content-center align-items-center"> <a href="<?php echo e(url('client')); ?>">
                <div class="admin-dashboard-col-inner h-100 w-100 orange-background p-4">
                    <!-- ADMIN DASHBOARD IMAGE  -->
                    <div class="working-details-icon d-flex justify-content-center " style="color: white;">
                        <i class="fas fa-user admin-dashboard-image"></i>
                    </div>
                    <!-- ADMIN DASHBOARD TEXT  -->
                   
                    <div class="admin-dashboard-text f-normal mt-5 text-center">
                        <p class="m-0">VIEW USER</p>
                    </div>
                   
                </div> </a>
            </div>

            <!-- ADMIN DASHBOARD COLUMN 5 -->
            <div class="col-sm-6 col-md-4 p-3 my-3 col-xl-3 admin-dashboard-col d-flex justify-content-center align-items-center"><a href="<?php echo e(url('result')); ?>">
                <div class="admin-dashboard-col-inner h-100 w-100 orange-background p-4">
                    <!-- ADMIN DASHBOARD IMAGE  -->
                    <div class="working-details-icon d-flex justify-content-center " style="color: white;">
                        <i class="fas fa-list-alt admin-dashboard-image"></i>
                    </div>
                    <!-- ADMIN DASHBOARD TEXT  -->
                    
                    <div class="admin-dashboard-text f-normal mt-5 text-center">
                        <p class="m-0">VIEW RESULTS</p>
                    </div>
                    
                </div></a>
            </div>

            <!-- ADMIN DASHBOARD COLUMN 6 -->
            <div class="col-sm-6 col-md-4 p-3 my-3 col-xl-3 admin-dashboard-col d-flex justify-content-center align-items-center">
                <div class="admin-dashboard-col-inner h-100 w-100 orange-background p-4"><a href="<?php echo e(url('dashboard')); ?>">
                    <!-- ADMIN DASHBOARD IMAGE  -->
                    <div class="working-details-icon d-flex justify-content-center " style="color: white;">
                        <i class="fas fa-columns admin-dashboard-image"></i>
                    </div>
                    <!-- ADMIN DASHBOARD TEXT  -->
                    
                    <div class="admin-dashboard-text f-normal mt-5 text-center">
                        <p class="m-0">VIEW DASHBOARD</p>
                    </div>
                    </a>
                </div>
            </div>


        </div>

        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bittaskc/public_html/uncat/uncatadmin/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>