<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UnCAT - Assessment Tool</title>

    <link rel="shortcut icon" href="media/logo.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
                  integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x"
                  crossorigin="anonymous">
    <!-- <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <link rel="stylesheet" href="css/animate.css"> -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css"> -->
    <!-- <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('admin_assets/css/style.css')); ?>">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap"
                  rel="stylesheet">
    <script src="https://kit.fontawesome.com/60a5beb53e.js" crossorigin="anonymous"></script>
</head>

<body>

    <!--************ NAVBAR ******************** -->

    <nav class="navbar navbar-expand-md navbar-light position-relative" id="header">
        <div class="container nav-container">
            <!-- NAVBAR BRAND  -->
            <a class="navbar-brand pl-2 pl-md-0" href="index.html">
                <img src="<?php echo e(URL::asset('admin_assets/media/uncat_logo.png')); ?>" alt="" class="logo-img img-responsive">
            </a>

            <!-- NAVBAR LINKS  -->
            <div class=" justify-content-end">
                <ul class="navbar-nav nav ml-auto black-clr">
                    <!-- NAV ITEM  -->
                    <li class="nav-item px-2 px-lg-3">
                        <a class="nav-link button white-color orange-background px-4 px-sm-5 f-semi-bold py-1"
                                      href="<?php echo e(url('clientlogout')); ?>">Logout <span class="sr-only">(current)</span></a>
                    </li>
                </ul>

            </div>
        </div>
    </nav>
    <!--************ NAVBAR END ******************** -->


    <!--************ INSTRUCTIONS ******************** -->

    <div class="instruction container my-5">
        <!-- INSTRUCTIONS MAIN HEADING  -->
        <div class="section-heading instructions-main-heading dark-blue-color mb-3 text-center">
            <h1 class="f-bold">
                Instructions
            </h1>
        </div>

        <!-- INSTRUCTIONS BOX  -->
        <div class="instructions-backdrop light-blue-background dark-blue-color p-4 p-md-5">
            <!-- WELCOME MESSAGE  -->
            <!-- <div class="section-heading instructions-main-heading dark-blue-color mb-3 text-start">
                <h1 class="f-bold">
                    Welcome Vinay
                </h1>
            </div> -->
            <!-- NAME OF THE PERSON  -->
            <div class="instructions-sub-heading my-5">
                <h4>Dear Respondent,</h4>
            </div>
            <!-- INSTRUCTIONS TEXT  -->
            <div class="instructions-text mb-5">
                <p>
                    You have been invited to take the UnCAT Assessment. This assessment consists of 16 scenarios
                    followed by questions.
                    <br><br>
                    UnCAT Assessment is designed to assess your mindset and understand your attitudes. This will help
                    you as you embark onto your career journey.
                    <br><br>

                    <strong>Informed Consent:</strong>
                    <br><br>
                    <strong>Kindly read the instructions carefully before proceeding. </strong>
                    <br>
                    <!-- INSTRUCTIONS LIST  -->
                <ol>
                    <li>
                        You must be 18+ years of age to take this assessment.
                    </li>
                    <li>
                        All your responses will be recorded and confidentiality will be maintained.
                    </li>
                    <li>
                        The questionnaire will take approximately 20 minutes to complete. However, please note this
                        is NOT a timed test.
                    </li>
                    <li>
                        There are five options for each question: 1- Strongly Disagree, 2- Disagree, 3- Neutral,
                        4-Agree, 5- Strongly Agree. You must select ONE option based on your opinions.
                    </li>
                    <li>
                        THERE ARE NO RIGHT OR WRONG ANSWERS. YOU ARE EXPECTED TO SELECT THE FIRST RESPONSE THAT COMES
                        TO YOUR MIND.
                    </li>
                </ol>
                By clicking the start button, you have agreed to participate in this assessment.
                </p>
            </div>
            <!-- INSTRUCTIONS BUTTON  -->
            <div class="instructions-btn-div text-center"> <?php if($question=="[]"): ?>
                <a href="<?php echo e(url('testquestion')); ?>" class="button instructions-btn dark-blue-background white-color f-semi-bold">
                     Start
                </a><?php else: ?>
                <a href="#" class="button instructions-btn dark-blue-background white-color f-semi-bold">
                    close
                </a><?php endif; ?>
            </div>
        </div>
    </div>



    <!--************ INSTRUCTIONS END ******************** -->




    <!--************ FOOTER ******************** -->

    <footer class="footer dark-blue-background">
        <div class="container footer-container py-5">
            <div class="row footer-row white-color position-relative">
                <!-- FOOTER COLUMN 1  -->
                <div class="col-md-6 footer-col my-3">
                    <!-- FOOTER COLUMN HEADING  -->
                    <div class="footer-col-heading">
                        <p>Contact Us:</p>
                    </div>
                    <!-- FOOTER COLUMN TEXT  -->
                    <div class="footer-col-text">
                        <a href="mailto:uncatserver@gmail.com" class="white-color">uncatserver@gmail.com</a>
                    </div>
                </div>

                <!-- FOOTER COLUMN 2 -->
                <div class="col-md-6 footer-col my-3 text-md-end">
                    <!-- FOOTER COLUMN HEADING  -->
                    <div class="footer-col-heading">
                        <p>Reach us at Tandemhive Global</p>
                    </div>
                    <!-- FOOTER COLUMN TEXT  -->
                    
                </div>
                <div class="footer-copyright mt-3 col-12">
                    <div class="copyright-content d-flex align-items-center justify-content-center">
                        <div class="copyright-text">
                            <p class="white-color m-0">Powered by - </p>
                        </div>
                        <div class="copyright-image-outer">
                            <img src="media/christ.png" alt="" class="copyright-img img-fluid ms-2">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>



    <!--************ FOOTER END ******************** -->




    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
                  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
                  integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
                  crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"
                  integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT"
                  crossorigin="anonymous"></script>
    <!-- <script src="js/wow.min.js"></script>
    <script src="js/owl.carousel.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script> -->
    <!-- <script data-cfasync="false" type="text/javascript" src="js/form-submission-handler.min.js" defer></script> -->
    <script type="text/javascript" src="<?php echo e(URL::asset('admin_assets/js/script.js')); ?>"></script>
</body>

</html><?php /**PATH /home/bittaskc/public_html/uncat/uncatadmin/resources/views/clientdashboard.blade.php ENDPATH**/ ?>