
	<!-- Bootstrap 4.0-->
	<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/bootstrap/dist/js/bootstrap.js')); ?>"></script>	
	
	<!-- date-range-picker -->
	<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/moment/min/moment.min.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
	
	<!-- FastClick -->
	<script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/fastclick/lib/fastclick.js')); ?>"></script>
	
    <!-- eChart Plugins -->
    <script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/echarts/dist/echarts-en.min.js')); ?>"></script>
	
    <!-- C3 Plugins -->
    <script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/c3/d3.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin_assets/assets/vendor_components/c3/c3.min.js')); ?>"></script>
	
	<!-- Ekan Admin App -->
	<script src="<?php echo e(URL::asset('admin_assets/js/template.js')); ?>"></script>
	
	<!-- Ekan Admin dashboard demo (This is only for demo purposes) -->
	<script src="<?php echo e(URL::asset('admin_assets/js/pages/dashboard.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('admin_assets/js/pages/dashboard-chart.js')); ?>"></script>
	
	<!-- Ekan Admin for demo purposes -->
	<script src="<?php echo e(URL::asset('admin_assets/js/demo.js')); ?>"></script>	
	<?php /**PATH /home3/scsyin/public_html/schoolbuddy/uncatadmin/resources/views/partner/include/script.blade.php ENDPATH**/ ?>