<html>
    <p>Welcome onboard , please click on partner.schoolbuddy. / login email id : <b><?php echo e($email); ?></b>  / password: <b><?php echo e($password); ?></b></p>
</html><?php /**PATH /home3/scsyin/public_html/schoolbuddy/uncatadmin/resources/views/admin/mail.blade.php ENDPATH**/ ?>