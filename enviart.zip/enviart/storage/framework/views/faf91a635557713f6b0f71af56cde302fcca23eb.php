
<?php $__env->startSection('content'); ?>

    <!--************ ADD-QUESTION ******************** -->

    <div class="container add-client my-5">
        <!-- ADD-QUESTION HEADING  -->
        <div class="section-heading instructions-main-heading dark-blue-color mb-3 text-center">
            <h1 class="f-bold">
                Add Question
            </h1>
        </div>
        <?php if(session()->has('status')): ?>
		<div class="alert alert-info">
				<?php echo e(session()->get('status')); ?>

			</div>
		<?php endif; ?>
        <form class="add-client-form my-5" action="<?php echo e(url('question/store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="d-block d-md-flex justify-content-between align-items-center">
                <div class="form-group my-3 w-100 d-flex justify-content-center">
                    <input type="text" class="form-control login-signup-input add-client-input py-3 orange-color"
                                  id="" aria-describedby="" placeholder="New Serial Number" required name="new_serial_number">
                </div>
                <div class="form-group my-3 w-100 d-flex justify-content-center">
                    <input type="text"
                                  class="form-control login-signup-input add-client-input py-3 orange-color "
                                  id="" placeholder="Old Serial Number" required name="old_serial_number">
                </div>
            </div>
            <div class="d-block d-md-flex justify-content-between align-items-center">
                <div class=" my-3 w-100 d-flex justify-content-center">
                    <select class="form-select login-signup-input add-client-input py-3 dark-blue-color" aria-label="Default select example" name="question_section">
                        <option selected>Select Question Section</option>
                        <option value="Gender Bias">A-Gender Bias</option>
                        <option value="Regional Bias">B-Regional Bias</option>
                        <option value="Religious Bias">C-Religious Bias</option>
                        <option value="Fundamental Attribution Error">D-Fundamental Attribution Error</option>
                        <option value="Hostile Attribution Error">E-Hostile Attribution Error</option>
                        <option value="Ageism">F-Ageism</option>
                        <option value="Actor Observer Bias">G-Actor Observer Bias</option>
                        <option value="Self-serving Bias">H-Self-serving Bias</option>
                        <option value="LGBTQIA+ Bias">I-LGBTQIA+ Bias</option>
                        <option value="Ultimate Attribute error">J-Ultimate Attribute error</option>
                        <option value="Affinity Bias">K-Affinity Bias</option>
                        <option value="Beauty Bias">L-Beauty Bias</option>
                        <option value="Ableism">M-Ableism</option>
                        <option value="Confirmation Bias">N-Confirmation Bias</option>
                        <option value="Conformity Bias">O-Conformity Bias</option>
                        <option value="Contrast Bias">P-Contrast Bias</option>
                        <option value="Halo Effect">Q-Halo Effect</option>
                        <option value="Horn Effect">R-Horn Effect</option>
                      </select>
                </div>
                <div class=" my-3 w-100 d-flex justify-content-center">
                    <select class="form-select login-signup-input add-client-input py-3 dark-blue-color" aria-label="Default select example" name="score_type">
                        <option selected>Select Score Type</option>
                        <option value="1">Direct Score</option>
                        <option value="2">Reverse Score</option>
                        <option value="3">SDQ</option>
                      </select>
                </div>
            </div>
            <div class="d-block d-md-flex justify-content-between align-items-center">
                <div class=" my-3 w-100 d-flex justify-content-center">
                    <textarea class="form-control login-signup-input add-client-text-area px-0 py-3 dark-blue-color px-2"  name="your_question" id="exampleFormControlTextarea1" rows="4" placeholder="Type Your Question"></textarea>
                </div>
            </div>
            

            <div class="submit-btn-outer text-center my-5">
                <button type="submit" class="button f-semi-bold dark-blue-background white-color login-signup-btn add-client-btn py-3">Submit</button>
            </div>
        </form>
    </div>



    <!--************ ADD-QUESTION END ******************** -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bittaskc/public_html/uncat/uncatadmin/resources/views/admin/question/create.blade.php ENDPATH**/ ?>