
<?php $__env->startSection('mainarea'); ?>
	<div class="container-fluid py-4">
      <div class="row">
        <div class="col-lg-9 col-12 mx-auto">
            <?php if(session()->has('status')): ?>
            <div class="alert alert-success" role="alert">
              <strong>Success!</strong> <?php echo e(session()->get('status')); ?>

          `</div>
    		<?php endif; ?>
    		<?php if($errors->any()): ?>
    		  <div class="alert alert-danger" role="alert" style="color:white;">
                  <strong>Warning!</strong>  <?php echo e(implode('', $errors->all(':message'))); ?>

              </div>
    		<?php endif; ?>
          <div class="card card-body mt-4">
            <form action="<?php echo e(url('admin/customer/store')); ?>" method="POST" enctype="multipart/form-data">
    			<?php echo csrf_field(); ?>
                <h6 class="mb-0">  <?php if(session('type')==0): ?> नया 
ग्राहक    <?php else: ?> New Customer   <?php endif; ?></h6>
                <hr class="horizontal dark my-3">
                <label for="projectName" class="form-label"> <?php if(session('type')==0): ?> ग्राहक नाम     <?php else: ?>  Customer Name  <?php endif; ?></label>
                <input type="text" class="form-control" name="customer_name"><br>
                <label for="projectName" class="form-label"> <?php if(session('type')==0): ?>  ग्राहक का पता    <?php else: ?> Customer Address  <?php endif; ?></label>
                <input type="text" class="form-control" name="customer_address"><br>
                <label for="projectName" class="form-label"> <?php if(session('type')==0): ?> ग्राहक  मोबाइल नंबर  <?php else: ?>  Customer Mobile No.  <?php endif; ?></label>
                <input type="text" class="form-control" name="customer_mobileno"><br>
                <label for="projectName" class="form-label"> <?php if(session('type')==0): ?>  ग्राहक ईमेल आईडी  <?php else: ?> Customer Email Id <?php endif; ?></label>
                <input type="text" class="form-control" name="customer_emailid"><br>
                <label for="projectName" class="form-label"> <?php if(session('type')==0): ?> 
ग्राहक जीएसटी नंबर  <?php else: ?>  Customer GST No.  <?php endif; ?></label>
                <input type="text" class="form-control" name="customer_gstno"><br>
                <label for="projectName" class="form-label"> <?php if(session('type')==0): ?>  ग्राहक पैन नंबर   <?php else: ?> Customer PAN No.  <?php endif; ?></label>
                <input type="text" class="form-control" name="customer_panno"><br>
                <div class="d-flex justify-content-end mt-4">
                  <button type="submit" name="button" class="btn bg-gradient-info m-0 ms-2"> <?php if(session('type')==0): ?> बनाएं     <?php else: ?> Create  <?php endif; ?></button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/whitdktw/nxtaccount.com/enviart/resources/views/admin/customer/create.blade.php ENDPATH**/ ?>